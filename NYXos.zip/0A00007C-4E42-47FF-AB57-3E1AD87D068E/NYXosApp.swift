import SwiftUI
import AVFoundation
import Combine
import WebKit
import Network
import CoreBluetooth
import UniformTypeIdentifiers
import CoreLocation
import PhotosUI

enum NyxApp: String, CaseIterable, Identifiable {
    case browser = "Horizon"
    case photos = "Photos"
    case weather = "Weather"
    case locations = "Locations"
    case aether = "Aether Toolset"
    case store = "App Store"
    case vault = "Vault"
    case prism = "Prism"
    case settings = "Settings"
    case downloads = "Downloads"
    case nyxManager = "NYxManager"
    case nyxSign = "NyxSign"
    case saveCodes = "Save Codes"
    case qiblaTracker = "Qibla Tracker"
    case notesApp = "Notes"
    case calculatorApp = "Calculator"
    
    var id: String { rawValue }
    
    var defaultIcon: String {
        switch self {
        case .browser: return "globe"
        case .photos: return "photo.on.rectangle.angled"
        case .weather: return "cloud.sun.fill"
        case .locations: return "location.fill"
        case .aether: return "wrench.and.screwdriver.fill"
        case .store: return "bag.fill"
        case .vault: return "shield.halved"
        case .prism: return "wand.and.stars"
        case .settings: return "gearshape.fill"
        case .downloads: return "arrow.down.circle.fill"
        case .nyxManager: return "lock.open.badge.gearshape"
        case .nyxSign: return "gamecontroller.fill"
        case .saveCodes: return "arrow.triangle.2.circlepath.icloud.fill"
        case .qiblaTracker: return "safari.fill"
        case .notesApp: return "square.and.pencil"
        case .calculatorApp: return "plus.slash.minus"
        }
    }
    
    var accentColor: Color {
        switch self {
        case .browser: return Color.cyan
        case .photos: return Color.pink
        case .weather: return Color.yellow
        case .locations: return Color.teal
        case .aether: return Color.green
        case .store: return Color.orange
        case .vault: return Color.purple
        case .prism: return Color.indigo
        case .settings: return Color.gray
        case .downloads: return Color.blue
        case .nyxManager: return Color.orange
        case .nyxSign: return Color.red
        case .saveCodes: return Color.mint
        case .qiblaTracker: return Color.green
        case .notesApp: return Color.yellow
        case .calculatorApp: return Color.blue
        }
    }
    
    var onboardingInfo: (description: String, usageGuide: String, features: [String]) {
        switch self {
        case .browser:
            return ("Secure Web Browsing Engine", "Enter any URL or browse built-in bookmarks.", ["WebKit Sandbox", "History Telemetry", "Encrypted Tunnel"])
        case .photos:
            return ("Media Gallery & Capture Viewer", "View photos, screenshots, and video recordings.", ["Cloud Sync", "Grid Layout", "Instant Deletion"])
        case .weather:
            return ("Meteorological Environment Monitor", "Track live temperature and conditions.", ["Live GPS", "UV Index", "Atmospheric Stats"])
        case .locations:
            return ("GPS Vector Tracker", "Monitor precise latitude and longitude data.", ["Real-time Coordinates", "Compass Heading", "Map Sync"])
        case .aether:
            return ("Aether Toolset & Terminal", "Execute root commands and diagnostics.", ["CLI Shell", "Root Exploit Hook", "Kernel Governor"])
        case .store:
            return ("Nyx App Store & Package Hub", "Download and install custom apps and games.", ["App Catalog", "Executables", "Sideloading"])
        case .vault:
            return ("Cryptographic Credential Manager", "Store passwords and secure notes safely.", ["Encrypted Keys", "PIN Lock", "Secure Notes"])
        case .prism:
            return ("OS Kernel & Theme Switcher", "Switch between multi-OS environments.", ["iOS 18 Theme", "Android Mode", "Linux Core"])
        case .settings:
            return ("System Configuration Hub", "Manage language preferences and system settings.", ["35+ Languages", "Accent Colors", "Display Toggles"])
        case .downloads:
            return ("Download Manager & File System", "Manage downloaded packages and files.", ["ZIP Support", "EXE Installer", "File Inspector"])
        case .nyxManager:
            return ("AI Tweak Compiler & Assistant", "Build apps and install tweaks using AI prompts.", ["AI Generation", "Tweak Manager", "Custom UI"])
        case .nyxSign:
            return ("Sideloading & IPA Signer Utility", "Sign and sideload external packages.", ["IPA Toolset", "Certificate Manager", "App Deployment"])
        case .saveCodes:
            return ("Cloud Save Code Backup Hub", "Export and restore your app configurations.", ["Base64 Backup", "Cloud Restore", "State Persistence"])
        case .qiblaTracker:
            return ("Qibla Compass & Mecca Bearings", "Find precise prayer directions anywhere.", ["True North", "Kaaba Bearings", "Live Coordinates"])
        case .notesApp:
            return ("Quick Notes & Scratchpad", "Write down thoughts and system scripts.", ["Markdown Support", "Local Persistence", "Quick Entry"])
        case .calculatorApp:
            return ("Advanced Mathematical Engine", "Perform calculations instantly.", ["Basic Arithmetic", "Memory Registers", "Clean UI"])
        }
    }
}

enum AppLanguage: String, CaseIterable, Identifiable {
    case english = "English"
    case arabic = "العربية"
    case korean = "한국어"
    case japanese = "日本語"
    case spanish = "Español"
    case french = "Français"
    case german = "Deutsch"
    
    var id: String { rawValue }
    
    var lockText: String {
        switch self {
        case .english: return "SWIPE UP OR TAP TO UNLOCK"
        case .arabic: return "اسحب أو انقر للفتح"
        case .korean: return "밀어서 잠금 해제"
        case .japanese: return "スワイプまたはタップしてロック解除"
        default: return "SWIPE UP OR TAP TO UNLOCK"
        }
    }
    
    func localizedAppName(_ app: NyxApp) -> String {
        switch app {
        case .browser: return self == .arabic ? "هورايزون" : "Horizon"
        case .photos: return self == .arabic ? "الصور" : "Photos"
        case .weather: return self == .arabic ? "الطقس" : "Weather"
        case .locations: return self == .arabic ? "المواقع" : "Locations"
        case .aether: return self == .arabic ? "أدوات أيثر" : "Aether Toolset"
        case .store: return self == .arabic ? "متجر التطبيقات" : "App Store"
        case .vault: return self == .arabic ? "الخزنة" : "Vault"
        case .prism: return self == .arabic ? "بريسم" : "Prism"
        case .settings: return self == .arabic ? "الإعدادات" : "Settings"
        case .downloads: return self == .arabic ? "التنزيلات" : "Downloads"
        case .nyxManager: return "NYxManager"
        case .nyxSign: return "NyxSign"
        case .saveCodes: return self == .arabic ? "رموز الحفظ" : "Save Codes"
        case .qiblaTracker: return self == .arabic ? "محدد القبلة" : "Qibla Tracker"
        case .notesApp: return self == .arabic ? "الملاحظات" : "Notes"
        case .calculatorApp: return self == .arabic ? "الآلة الحاسبة" : "Calculator"
        }
    }
}

enum OperatingSystemMode: String, CaseIterable, Identifiable {
    case ios18 = "iOS 18 Liquid Glass"
    case android = "Android 14 Nyx"
    case windows = "Windows 11 Nyx"
    case linux = "Linux Kernel"
    case cyberpunk = "Cyberpunk 2077 OS"
    case nyx = "Nyx OS Stock"
    case off = "Prism Off"
    
    var id: String { rawValue }
    
    var accent: Color {
        switch self {
        case .ios18: return Color.pink
        case .android: return Color.green
        case .windows: return Color.blue
        case .linux: return Color.purple
        case .cyberpunk: return Color.yellow
        case .nyx: return Color.cyan
        case .off: return Color.gray
        }
    }
}

struct StoreApp: Identifiable {
    let id = UUID()
    let name: String
    let icon: String
    let description: String
    let accent: Color
    let isGame: Bool
    var isInstalled: Bool = false
    var isExeApp: Bool = false
    var exeFilename: String? = nil
}

struct DownloadedFileItem: Identifiable {
    let id = UUID()
    let filename: String
    let filesize: String
    let date: Date
}

struct PublishedTweak: Identifiable {
    let id = UUID()
    let title: String
    let author: String
    let description: String
    var isEnabled: Bool = false
}

struct CustomAIApp: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String
    var promptText: String
    var bounceCharacter: String
    var appCategoryRaw: String
    var icon: String
    var isDownloaded: Bool = false
    var downloadProgress: Double = 0.0
    
    enum AppType: String, Codable {
        case bouncer, calculator, notes, clickerGame, chatbot, customSaveCodes
    }
    
    var appCategory: AppType {
        get { AppType(rawValue: appCategoryRaw) ?? .chatbot }
        set { appCategoryRaw = newValue.rawValue }
    }
}

struct SideloaderGame: Identifiable {
    let id = UUID()
    let title: String
    let format: String
    let size: String
    var isInstalledOnHomescreen: Bool = false
}

struct VaultNote: Identifiable {
    let id = UUID()
    let title: String
    let content: String
    let date: Date
}

struct PhotoMediaItem: Identifiable {
    let id = UUID()
    let name: String
    let type: String // "Photo", "Screenshot", "Recording"
    let date: Date
    var image: UIImage? = nil
}

struct WindowItem: Identifiable {
    let id = UUID()
    let app: NyxApp
    var position: CGPoint
    var size: CGSize
}

final class RealNetworkMonitor: NSObject, ObservableObject, CLLocationManagerDelegate, CBCentralManagerDelegate {
    private let monitor = NWPathMonitor()
    private let queue = DispatchQueue(label: "NyxNetworkMonitorQueue")
    private let locationManager = CLLocationManager()
    private var centralManager: CBCentralManager!
    
    @Published var isConnected: Bool = true
    @Published var connectionType: String = "Wi-Fi"
    @Published var currentWifiSSID: String = "Active Wi-Fi Network"
    @Published var discoveredBluetoothDevices: [String] = []
    @Published var deviceCoordinates: String = "Lat: 24.4539° N, Lon: 39.6142° E (Mocked)"
    
    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        let status = locationManager.authorizationStatus
        if status == .notDetermined {
            locationManager.requestWhenInUseAuthorization()
        }
        if status == .authorizedWhenInUse || status == .authorizedAlways {
            locationManager.startUpdatingLocation()
        }
        
        centralManager = CBCentralManager(delegate: self, queue: nil)
        
        monitor.pathUpdateHandler = { [weak self] path in
            DispatchQueue.main.async {
                self?.isConnected = (path.status == .satisfied)
                if path.usesInterfaceType(.wifi) {
                    self?.connectionType = "Wi-Fi"
                    self?.currentWifiSSID = "Connected Wi-Fi Interface"
                } else if path.usesInterfaceType(.cellular) {
                    self?.connectionType = "Cellular"
                    self?.currentWifiSSID = "Cellular Data Network"
                } else {
                    self?.connectionType = "Offline"
                    self?.currentWifiSSID = "No Active Link"
                }
            }
        }
        monitor.start(queue: queue)
    }
    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn {
            central.scanForPeripherals(withServices: nil, options: nil)
        } else {
            DispatchQueue.main.async {
                self.discoveredBluetoothDevices = ["Bluetooth Hardware Powered Off"]
            }
        }
    }
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        let name = peripheral.name ?? "Unnamed BLE Peripheral"
        DispatchQueue.main.async {
            if !self.discoveredBluetoothDevices.contains(name) {
                self.discoveredBluetoothDevices.append(name)
            }
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let loc = locations.last else { return }
        DispatchQueue.main.async {
            self.deviceCoordinates = String(format: "Lat: %.4f° N, Lon: %.4f° E", loc.coordinate.latitude, loc.coordinate.longitude)
        }
    }
}

final class NyxAudioEngine: ObservableObject {
    func playClickHaptic() { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
    func playLockChime() { UINotificationFeedbackGenerator().notificationOccurred(.success) }
    func playShutterSound() { UINotificationFeedbackGenerator().notificationOccurred(.warning) }
}

final class NyxOSViewModel: ObservableObject {
    @Published var isLandscape: Bool = false
    @Published var geminiApiKey: String = ""
    @Published var isLoggedIn: Bool = false
    @Published var loggedInUserProvider: String = ""
    @Published var showAppByAppOnboarding: Bool = false
    @Published var onboardingAppIndex: Int = 0
    @Published var isLocked: Bool = false
    @Published var isScreenOn: Bool = true
    @Published var volumeLevel: Double = 0.5
    @Published var screenBrightness: Double = 0.95
    @Published var showVolumeHUD: Bool = false
    @Published var batteryLevel: Double = 0.88
    @Published var isCharging: Bool = false
    @Published var wifiEnabled: Bool = true
    @Published var bluetoothEnabled: Bool = true
    @Published var connectedBluetoothDevice: String = "AirPods Pro (Nyx)"
    @Published var flashlightEnabled: Bool = false
    @Published var activeApp: NyxApp? = nil
    @Published var activeStoreAppGame: StoreApp? = nil
    @Published var activeExeApp: StoreApp? = nil
    @Published var activeSideloadGame: SideloaderGame? = nil
    @Published var activeCustomAiApp: CustomAIApp? = nil
    @Published var isDesktopModeActive: Bool = false
    @Published var isControlCenterOpen: Bool = false
    @Published var isRecordingScreen: Bool = false
    @Published var triggerFlashAnimation: Bool = false
    @Published var currentLanguage: AppLanguage = .english
    @Published var osMode: OperatingSystemMode = .nyx
    @Published var systemAccentColor: Color = Color.cyan
    @Published var showVirtualKeyboard: Bool = false
    @Published var virtualKeyPressedOutput: String = "None"
    @Published var downloadedFiles: [DownloadedFileItem] = [
        DownloadedFileItem(filename: "WelcomePackage.zip", filesize: "4.5 MB", date: Date())
    ]
    @Published var showDownloadsAppUnlocked: Bool = true
    @Published var showNyxSignUnlocked: Bool = false
    @Published var isJailbroken: Bool = false
    @Published var isRebooting: Bool = false
    @Published var showWindowsExeInstaller: Bool = false
    @Published var pendingExeFileName: String = ""
    @Published var hiddenApps: Set<String> = []
    @Published var deletedApps: Set<String> = []
    @Published var customAppIcons: [String: String] = [:]
    @Published var searchFilterText: String = ""
    @Published var selectedAiEngine: String = "Gemini"
    @Published var hideDynamicIslandBadge: Bool = false
    @Published var isCpuOverclocked: Bool = false
    @Published var customStatusBarLabel: String = ""
    @Published var isLightMode: Bool = false
    @Published var showAlertMessage: Bool = false
    @Published var alertTitleText: String = ""
    @Published var alertBodyText: String = ""
    
    @Published var vaultNotes: [VaultNote] = [
        VaultNote(title: "Root Passwords", content: "nyx_admin_99#root", date: Date()),
        VaultNote(title: "Crypto Wallet Seed", content: "orbit luxury crystal phantom matrix quantum code", date: Date())
    ]
    
    @Published var publishedTweaks: [PublishedTweak] = [
        PublishedTweak(title: "KernelSpeed Pro", author: "NyxDev", description: "Unlocks core performance boost.", isEnabled: false),
        PublishedTweak(title: "Utillity", author: "NyxRoot", description: "Hides the rooted status badge.", isEnabled: false),
        PublishedTweak(title: "NyxSplit Multitasker", author: "NyxRoot", description: "Enables floating side-by-side multitasking.", isEnabled: false),
        PublishedTweak(title: "Prism OS Expander", author: "NyxKernel", description: "Unlocks full iOS 18, Android, Windows & Linux OS switching.", isEnabled: false)
    ]
    
    @Published var photoGalleryItems: [PhotoMediaItem] = [
        PhotoMediaItem(name: "Wallpaper Aurora", type: "Photo", date: Date()),
        PhotoMediaItem(name: "System Snapshot 1", type: "Screenshot", date: Date()),
        PhotoMediaItem(name: "Neon Skyline", type: "Photo", date: Date())
    ]
    
    @Published var customAiApps: [CustomAIApp] = []
    
    @Published var sideloadedGames: [SideloaderGame] = [
        SideloaderGame(title: "Cyberpunk 2077 Mobile", format: ".ipa", size: "1.4 GB", isInstalledOnHomescreen: false),
        SideloaderGame(title: "Minecraft Java Client", format: ".jar", size: "350 MB", isInstalledOnHomescreen: false)
    ]
    
    @Published var storeCatalog: [StoreApp] = [
        StoreApp(name: "Roblox", icon: "cube.fill", description: "Metaverse Client Platform", accent: Color.red, isGame: true, isInstalled: false),
        StoreApp(name: "Void Runner", icon: "gamecontroller.fill", description: "PC Action Platformer", accent: Color.orange, isGame: true, isInstalled: false)
    ]
    
    func login(provider: String) {
        withAnimation {
            isLoggedIn = true
            loggedInUserProvider = provider
            showAppByAppOnboarding = true
            onboardingAppIndex = 0
        }
    }
    
    func unlockDevice() {
        withAnimation { isLocked = false }
    }
    
    func switchOS(to mode: OperatingSystemMode) {
        withAnimation(.easeInOut(duration: 0.5)) {
            osMode = mode
            systemAccentColor = mode.accent
            if mode == .windows || mode == .linux {
                isDesktopModeActive = true
            }
        }
    }
    
    func generateSaveCode() -> String {
        do {
            let data = try JSONEncoder().encode(customAiApps)
            return data.base64EncodedString()
        } catch {
            return "NYX-EMPTY-CODE"
        }
    }
    
    func takeScreenshot() {
        withAnimation(.easeOut(duration: 0.15)) { triggerFlashAnimation = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            withAnimation { self.triggerFlashAnimation = false }
        }
        
        let capturedImage: UIImage? = {
            guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                  let window = scene.windows.first else { return nil }
            let renderer = UIGraphicsImageRenderer(bounds: window.bounds)
            return renderer.image { _ in
                window.drawHierarchy(in: window.bounds, afterScreenUpdates: true)
            }
        }()
        
        let shotName = "Screenshot \(Date().formatted(date: .omitted, time: .standard))"
        let newShot = PhotoMediaItem(name: shotName, type: "Screenshot", date: Date(), image: capturedImage)
        photoGalleryItems.insert(newShot, at: 0)
        
        let downloadItem = DownloadedFileItem(filename: "\(shotName).png", filesize: "3.2 MB", date: Date())
        downloadedFiles.insert(downloadItem, at: 0)
    }
    
    func deletePhoto(id: UUID) {
        photoGalleryItems.removeAll(where: { $0.id == id })
    }
    
    func addImportedPhoto(name: String, image: UIImage) {
        let newPhoto = PhotoMediaItem(name: name, type: "Imported", date: Date(), image: image)
        photoGalleryItems.insert(newPhoto, at: 0)
    }
    
    func toggleScreenRecording() {
        if isRecordingScreen {
            isRecordingScreen = false
            
            let capturedImage: UIImage? = {
                guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                      let window = scene.windows.first else { return nil }
            let renderer = UIGraphicsImageRenderer(bounds: window.bounds)
            return renderer.image { _ in
                window.drawHierarchy(in: window.bounds, afterScreenUpdates: true)
            }
            }()
            
            let recName = "Screen Rec \(Date().formatted(date: .omitted, time: .standard))"
            let rec = PhotoMediaItem(name: recName, type: "Recording", date: Date(), image: capturedImage)
            photoGalleryItems.insert(rec, at: 0)
            
            let downloadItem = DownloadedFileItem(filename: "\(recName).mp4", filesize: "450.0 MB", date: Date())
            downloadedFiles.insert(downloadItem, at: 0)
        } else {
            isRecordingScreen = true
        }
    }
    
    func triggerJailbreakReboot() {
        withAnimation { isRebooting = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) {
            withAnimation {
                self.isJailbroken = true
                self.osMode = .ios18
                self.systemAccentColor = OperatingSystemMode.ios18.accent
                self.isRebooting = false
            }
        }
    }
    
    func triggerRemoveJailbreakReboot() {
        withAnimation { isRebooting = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) {
            withAnimation {
                self.isJailbroken = false
                self.isCpuOverclocked = false
                self.isDesktopModeActive = false
                self.osMode = .nyx
                self.systemAccentColor = OperatingSystemMode.nyx.accent
                for i in 0..<self.publishedTweaks.count {
                    self.publishedTweaks[i].isEnabled = false
                }
                self.isRebooting = false
            }
        }
    }
    
    func publishCustomTweak(title: String, desc: String) {
        let newTweak = PublishedTweak(title: title, author: "RootUser", description: desc, isEnabled: false)
        publishedTweaks.append(newTweak)
    }
    
    func sideloadAndInstallGame(id: UUID) {
        if let index = sideloadedGames.firstIndex(where: { $0.id == id }) {
            sideloadedGames[index].isInstalledOnHomescreen = true
        }
    }
    
    func installStoreApp(id: UUID) {
        if let index = storeCatalog.firstIndex(where: { $0.id == id }) {
            storeCatalog[index].isInstalled = true
        }
    }
    
    func addDownloadedFileFromHorizon(filename: String) {
        let newItem = DownloadedFileItem(filename: filename, filesize: "12.4 MB", date: Date())
        downloadedFiles.insert(newItem, at: 0)
    }
    
    func openDownloadedFile(item: DownloadedFileItem) {
        let fname = item.filename.lowercased()
        if fname.hasSuffix(".exe") {
            pendingExeFileName = item.filename
            showWindowsExeInstaller = true
        } else if fname.hasSuffix(".ipa") || fname.hasSuffix(".apk") || fname.hasSuffix(".jar") {
            let title = item.filename.replacingOccurrences(of: ".ipa", with: "").replacingOccurrences(of: ".apk", with: "").replacingOccurrences(of: ".jar", with: "").capitalized
            sideloadedGames.append(SideloaderGame(title: title, format: fname.hasSuffix(".ipa") ? ".ipa" : ".apk", size: item.filesize, isInstalledOnHomescreen: true))
            alertTitleText = "Package Installed"
            alertBodyText = "\(item.filename) has been successfully sideloaded and installed to your home screen!"
            showAlertMessage = true
        } else if fname.hasSuffix(".html") || fname.hasSuffix(".htm") {
            activeApp = .browser
        } else {
            alertTitleText = "File Opened"
            alertBodyText = "Successfully parsed and opened \(item.filename)."
            showAlertMessage = true
        }
    }
    
    func confirmWindowsInstallation() {
        showWindowsExeInstaller = false
        let cleanName = pendingExeFileName.replacingOccurrences(of: ".exe", with: "", options: .caseInsensitive).capitalized
        let newApp = StoreApp(name: cleanName, icon: "cube.box.fill", description: "Win32 Executable Application", accent: Color.blue, isGame: false, isInstalled: true, isExeApp: true, exeFilename: pendingExeFileName)
        storeCatalog.append(newApp)
        activeExeApp = newApp
        pendingExeFileName = ""
    }
    
    func addVaultNote(title: String, content: String) {
        let note = VaultNote(title: title, content: content, date: Date())
        vaultNotes.append(note)
    }
}

@main
struct NyxOSApp: App {
    var body: some Scene {
        WindowGroup {
            ZStack {
                Color.black.ignoresSafeArea()
                NyxOSPhoneView()
            }
        }
    }
}

struct NyxOSPhoneView: View {
    @StateObject private var viewModel = NyxOSViewModel()
    @StateObject private var audioEngine = NyxAudioEngine()
    @StateObject private var networkMonitor = RealNetworkMonitor()
    
    var body: some View {
        Group {
            if viewModel.isLandscape {
                VStack(spacing: 0) {
                    HStack(spacing: 12) {
                        Button(action: { audioEngine.playClickHaptic(); viewModel.volumeLevel = min(1.0, viewModel.volumeLevel + 0.1) }) {
                            RoundedRectangle(cornerRadius: 2).fill(Color.gray.opacity(0.6)).frame(width: 35, height: 4)
                        }
                        
                        Button(action: {
                            audioEngine.playShutterSound()
                            viewModel.takeScreenshot()
                        }) {
                            RoundedRectangle(cornerRadius: 2).fill(Color.gray.opacity(0.6)).frame(width: 35, height: 4)
                        }
                    }
                    .padding(.bottom, 4)
                    
                    ZStack {
                        RoundedRectangle(cornerRadius: 36)
                            .fill(viewModel.osMode == .android ? Color(red: 0.08, green: 0.1, blue: 0.09) : Color(white: 0.15))
                            .shadow(color: viewModel.systemAccentColor.opacity(0.4), radius: 25)
                            .overlay(
                                RoundedRectangle(cornerRadius: 36)
                                    .stroke(viewModel.systemAccentColor.opacity(0.5), lineWidth: 2)
                            )
                        
                        phoneContentLayer
                    }
                    .frame(width: 600, height: 360)
                    
                    HStack {
                        Button(action: { audioEngine.playClickHaptic(); withAnimation { viewModel.isScreenOn.toggle() } }) {
                            RoundedRectangle(cornerRadius: 2).fill(Color.gray.opacity(0.6)).frame(width: 50, height: 4)
                        }
                    }
                    .padding(.top, 4)
                }
            } else {
                HStack(spacing: 0) {
                    VStack(spacing: 12) {
                        Button(action: { audioEngine.playClickHaptic(); viewModel.volumeLevel = min(1.0, viewModel.volumeLevel + 0.1) }) {
                            RoundedRectangle(cornerRadius: 2).fill(Color.gray.opacity(0.6)).frame(width: 4, height: 35)
                        }
                        
                        Button(action: {
                            audioEngine.playShutterSound()
                            viewModel.takeScreenshot()
                        }) {
                            RoundedRectangle(cornerRadius: 2).fill(Color.gray.opacity(0.6)).frame(width: 4, height: 35)
                        }
                    }
                    .padding(.trailing, 4)
                    
                    ZStack {
                        RoundedRectangle(cornerRadius: 36)
                            .fill(viewModel.osMode == .android ? Color(red: 0.08, green: 0.1, blue: 0.09) : Color(white: 0.15))
                            .shadow(color: viewModel.systemAccentColor.opacity(0.4), radius: 25)
                            .overlay(
                                RoundedRectangle(cornerRadius: 36)
                                    .stroke(viewModel.systemAccentColor.opacity(0.5), lineWidth: 2)
                            )
                        
                        phoneContentLayer
                    }
                    .frame(width: 360, height: 600)
                    
                    VStack {
                        Button(action: { audioEngine.playClickHaptic(); withAnimation { viewModel.isScreenOn.toggle() } }) {
                            RoundedRectangle(cornerRadius: 2).fill(Color.gray.opacity(0.6)).frame(width: 4, height: 50)
                        }
                    }
                    .padding(.leading, 4)
                }
            }
        }
        .animation(.spring(response: 0.4, dampingFraction: 0.75), value: viewModel.isLandscape)
    }
    
    @ViewBuilder
    private var phoneContentLayer: some View {
        ZStack {
            Group {
                if viewModel.osMode == .ios18 {
                    LinearGradient(colors: [Color.pink.opacity(0.2), Color.indigo.opacity(0.3), Color.black], startPoint: .topLeading, endPoint: .bottomTrailing)
                        .ignoresSafeArea()
                } else if viewModel.isLightMode {
                    Color(white: 0.92).ignoresSafeArea()
                } else {
                    Color(red: 0.03, green: 0.03, blue: 0.06).ignoresSafeArea()
                }
            }
            
            if !viewModel.isScreenOn {
                Color.black.ignoresSafeArea().zIndex(500)
            } else if !viewModel.isLoggedIn {
                LoginSignupScreenView(viewModel: viewModel, audioEngine: audioEngine)
                    .zIndex(450)
            } else if viewModel.showAppByAppOnboarding {
                AppByAppOnboardingWizardView(viewModel: viewModel, audioEngine: audioEngine)
                    .zIndex(440)
            } else if viewModel.isRebooting {
                VStack(spacing: 12) {
                    ProgressView().progressViewStyle(CircularProgressViewStyle(tint: viewModel.systemAccentColor))
                    Text("REBOOTING KERNEL...").font(.system(size: 11, weight: .bold, design: .monospaced)).foregroundColor(viewModel.systemAccentColor)
                    Text("Applying kernel state changes").font(.system(size: 9)).foregroundColor(.gray)
                }
            } else if viewModel.isLocked {
                LockScreenView(viewModel: viewModel, audioEngine: audioEngine)
            } else if viewModel.isDesktopModeActive {
                ComputerDesktopEnvironmentView(viewModel: viewModel, audioEngine: audioEngine, networkMonitor: networkMonitor)
            } else {
                HomeScreenView(viewModel: viewModel, audioEngine: audioEngine)
            }
            
            if let activeApp = viewModel.activeApp, !viewModel.isDesktopModeActive {
                AppContainerView(app: activeApp, viewModel: viewModel, audioEngine: audioEngine, networkMonitor: networkMonitor)
                    .transition(.move(edge: .bottom))
                    .zIndex(100)
            }
            
            if let customApp = viewModel.activeCustomAiApp {
                CustomAIAppContainerView(customApp: customApp, viewModel: viewModel, audioEngine: audioEngine)
                    .transition(.move(edge: .bottom))
                    .zIndex(190)
            }
            
            if let game = viewModel.activeStoreAppGame {
                RunningGameContainerView(game: game, viewModel: viewModel, audioEngine: audioEngine)
                    .transition(.move(edge: .bottom))
                    .zIndex(170)
            }
            
            if let sideloadItem = viewModel.activeSideloadGame {
                RunningSideloadGameContainer(game: sideloadItem, viewModel: viewModel, audioEngine: audioEngine)
                    .transition(.move(edge: .bottom))
                    .zIndex(180)
            }
            
            if let exeApp = viewModel.activeExeApp {
                RunningExeAppContainerView(exeApp: exeApp, viewModel: viewModel, audioEngine: audioEngine)
                    .transition(.move(edge: .bottom))
                    .zIndex(150)
            }
            
            if viewModel.isControlCenterOpen {
                AdvancedControlCenterOverlay(viewModel: viewModel, audioEngine: audioEngine, networkMonitor: networkMonitor)
                    .transition(.move(edge: .top))
                    .zIndex(200)
            }
            
            if viewModel.showWindowsExeInstaller {
                WindowsExeInstallerPopup(viewModel: viewModel, audioEngine: audioEngine)
                    .transition(.opacity)
                    .zIndex(250)
            }
            
            if viewModel.showAlertMessage {
                VStack(spacing: 10) {
                    Text(viewModel.alertTitleText).font(.system(size: 11, weight: .bold)).foregroundColor(.red)
                    Text(viewModel.alertBodyText).font(.system(size: 9)).foregroundColor(.white).multilineTextAlignment(.center)
                    Button("Dismiss") { viewModel.showAlertMessage = false }
                        .font(.system(size: 9, weight: .bold)).padding(.horizontal, 14).padding(.vertical, 6)
                        .background(Color.red).foregroundColor(.white).clipShape(Capsule())
                }
                .padding(16)
                .background(viewModel.osMode == .android ? Color(red: 0.12, green: 0.15, blue: 0.14) : Color.black.opacity(0.6))
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .shadow(radius: 10)
                .zIndex(350)
            }
            
            Color.black.opacity(1.0 - viewModel.screenBrightness)
                .allowsHitTesting(false)
                .zIndex(400)
            
            if viewModel.triggerFlashAnimation {
                Color.white.ignoresSafeArea()
                    .transition(.opacity)
                    .zIndex(450)
            }
            
            VStack {
                if !viewModel.isDesktopModeActive {
                    HybridStatusBarView(viewModel: viewModel, audioEngine: audioEngine, networkMonitor: networkMonitor)
                }
                Spacer()
                if !viewModel.isDesktopModeActive {
                    AndroidGestureNavBar(viewModel: viewModel, audioEngine: audioEngine)
                }
            }
            .zIndex(410)
            .allowsHitTesting(true)
        }
        .clipShape(RoundedRectangle(cornerRadius: 32))
        .padding(8)
    }
}

// Background modifier helper returning a proper View modifier
@ViewBuilder
func getBackgroundView(for mode: OperatingSystemMode) -> some View {
    if mode == .ios18 {
        Color.clear.background(.ultraThinMaterial)
    } else if mode == .android {
        Color(red: 0.12, green: 0.15, blue: 0.14)
    } else {
        Color(red: 0.1, green: 0.1, blue: 0.15).opacity(0.85)
    }
}

// Helper returning explicit ShapeStyle for shape fills
func getBackgroundShapeStyle(for mode: OperatingSystemMode) -> AnyShapeStyle {
    if mode == .ios18 {
        return AnyShapeStyle(.ultraThinMaterial)
    } else if mode == .android {
        return AnyShapeStyle(Color(red: 0.12, green: 0.15, blue: 0.14))
    } else {
        return AnyShapeStyle(Color(red: 0.1, green: 0.1, blue: 0.15).opacity(0.85))
    }
}

struct LoginSignupScreenView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    
    @State private var emailInput: String = ""
    @State private var passwordInput: String = ""
    @State private var showDiscordAuthBrowser: Bool = false
    @State private var showGoogleAuthBrowser: Bool = false
    @State private var showEmailVerificationPopup: Bool = false
    @State private var enteredVerificationCode: String = ""
    @State private var generatedSecureCode: String = ""
    @State private var pendingGoogleAccount: String = ""
    @State private var authWebURL: URL = URL(string: "https://discord.com/login")!
    @State private var googleAuthURL: URL = URL(string: "https://accounts.google.com/signin")!
    @State private var detectedUsername: String = "Detecting..."
    
    @State private var showValidationError: Bool = false
    @State private var validationErrorMessage: String = ""
    
    var body: some View {
        ZStack {
            VStack(spacing: 16) {
                Spacer()
                
                Image(systemName: "sparkles.rectangle.stack.fill")
                    .font(.system(size: 50))
                    .foregroundColor(viewModel.systemAccentColor)
                    .shadow(color: viewModel.systemAccentColor.opacity(0.5), radius: 10)
                
                VStack(spacing: 4) {
                    Text("WELCOME TO NYXOS")
                        .font(.system(size: 15, weight: .black, design: .monospaced))
                        .foregroundColor(.white)
                    Text("Secure Authentication Gate")
                        .font(.system(size: 8))
                        .foregroundColor(.gray)
                }
                
                VStack(spacing: 10) {
                    TextField("Enter email / handle", text: $emailInput)
                        .font(.system(size: 10))
                        .padding(10)
                        .background(getBackgroundView(for: viewModel.osMode))
                        .foregroundColor(.white)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                    
                    SecureField("Security Password", text: $passwordInput)
                        .font(.system(size: 10))
                        .padding(10)
                        .background(getBackgroundView(for: viewModel.osMode))
                        .foregroundColor(.white)
                    
                    Button(action: {
                        let trimmedEmail = emailInput.trimmingCharacters(in: .whitespacesAndNewlines)
                        let trimmedPass = passwordInput.trimmingCharacters(in: .whitespacesAndNewlines)
                        
                        if trimmedEmail.isEmpty || trimmedPass.isEmpty {
                            audioEngine.playShutterSound()
                            validationErrorMessage = "Please enter both an email/handle and password."
                            showValidationError = true
                        } else if !trimmedEmail.contains("@") && trimmedEmail.count < 3 {
                            audioEngine.playShutterSound()
                            validationErrorMessage = "Please enter a valid email address."
                            showValidationError = true
                        } else {
                            audioEngine.playLockChime()
                            viewModel.login(provider: trimmedEmail)
                        }
                    }) {
                        Text("Authenticate & Boot OS")
                            .font(.system(size: 10, weight: .bold))
                            .frame(maxWidth: .infinity, minHeight: 38)
                            .background(viewModel.systemAccentColor)
                            .foregroundColor(.black)
                            .clipShape(RoundedRectangle(cornerRadius: viewModel.osMode == .android ? 20 : 10))
                    }
                }
                .padding(.horizontal, 24)
                
                Spacer().frame(height: 10)
                
                VStack(spacing: 8) {
                    Text("External App Authentication Handshake").font(.system(size: 7, weight: .bold, design: .monospaced)).foregroundColor(.gray)
                    
                    HStack(spacing: 8) {
                        Button(action: {
                            audioEngine.playClickHaptic()
                            authWebURL = URL(string: "https://discord.com/login")!
                            showDiscordAuthBrowser = true
                        }) {
                            HStack(spacing: 4) {
                                Image(systemName: "gamecontroller.fill").font(.system(size: 9))
                                Text("Discord Auth")
                            }
                            .font(.system(size: 8, weight: .bold))
                            .frame(maxWidth: .infinity, minHeight: 32)
                            .background(Color(red: 0.34, green: 0.4, blue: 0.9))
                            .foregroundColor(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                        }
                        
                        Button(action: {
                            audioEngine.playClickHaptic()
                            googleAuthURL = URL(string: "https://accounts.google.com/signin")!
                            showGoogleAuthBrowser = true
                        }) {
                            HStack(spacing: 4) {
                                Image(systemName: "globe").font(.system(size: 9))
                                Text("Google Auth")
                            }
                            .font(.system(size: 8, weight: .bold))
                            .frame(maxWidth: .infinity, minHeight: 32)
                            .background(Color.white)
                            .foregroundColor(.black)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                        }
                    }
                }
                .padding(.horizontal, 24)
                
                Spacer()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            if showValidationError {
                VStack(spacing: 10) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.system(size: 26))
                        .foregroundColor(.red)
                    Text("Authentication Required")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(.white)
                    Text(validationErrorMessage)
                        .font(.system(size: 9))
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                    Button("OK") { showValidationError = false }
                        .font(.system(size: 9, weight: .bold))
                        .padding(.horizontal, 16).padding(.vertical, 6)
                        .background(Color.red)
                        .foregroundColor(.white)
                        .clipShape(Capsule())
                }
                .padding(16)
                .frame(width: 250)
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .shadow(radius: 20)
                .zIndex(800)
            }
            
            if showDiscordAuthBrowser {
                VStack(spacing: 0) {
                    HStack {
                        Image(systemName: "gamecontroller.fill").foregroundColor(Color(red: 0.34, green: 0.4, blue: 0.9))
                        Text("Auto-Detecting Discord Session").font(.system(size: 10, weight: .bold)).foregroundColor(.white)
                        Spacer()
                        Button("Close") { showDiscordAuthBrowser = false }
                            .font(.system(size: 9, weight: .bold)).foregroundColor(.red)
                    }
                    .padding(10)
                    .background(Color(white: 0.12))
                    
                    DiscordScrapingWebView(url: $authWebURL, onUsernameFound: { username in
                        if !username.isEmpty {
                            self.detectedUsername = username
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                self.showDiscordAuthBrowser = false
                                self.viewModel.login(provider: "Discord: \(username)")
                            }
                        }
                    })
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    
                    HStack(spacing: 10) {
                        Text("Detected: \(detectedUsername)").font(.system(size: 8, weight: .bold, design: .monospaced)).foregroundColor(.cyan)
                        Spacer()
                    }
                    .padding(10)
                    .background(Color(white: 0.1))
                }
                .background(Color.black)
                .clipShape(RoundedRectangle(cornerRadius: 24))
                .padding(20)
                .shadow(radius: 20)
                .zIndex(600)
            }
            
            if showGoogleAuthBrowser {
                VStack(spacing: 0) {
                    HStack {
                        Image(systemName: "globe").foregroundColor(Color.red)
                        Text("Secure Google Auth Gate").font(.system(size: 10, weight: .bold)).foregroundColor(.white)
                        Spacer()
                        Button("Close") { showGoogleAuthBrowser = false }
                            .font(.system(size: 9, weight: .bold)).foregroundColor(.red)
                    }
                    .padding(10)
                    .background(Color(white: 0.12))
                    
                    GoogleScrapingWebView(url: $googleAuthURL, onAccountFound: { accountName in
                        DispatchQueue.main.async {
                            self.pendingGoogleAccount = accountName
                            self.showGoogleAuthBrowser = false
                            
                            let code = String(format: "%06d", Int.random(in: 100000..<1000000))
                            self.generatedSecureCode = code
                            self.showEmailVerificationPopup = true
                            
                            let resendApiKey = "re_R7YS4B2T_3n9Ly4xKGvB8eqeEC68hw9eu"
                            guard let url = URL(string: "https://api.resend.com/emails") else { return }
                            var request = URLRequest(url: url)
                            request.httpMethod = "POST"
                            request.setValue("Bearer \(resendApiKey)", forHTTPHeaderField: "Authorization")
                            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                            
                            let body: [String: Any] = [
                                "from": "NyxOS Verification <onboarding@resend.dev>",
                                "to": [accountName],
                                "subject": "Your NyxOS Verification Code",
                                "html": "<div style='font-family:sans-serif;padding:20px;background:#0b0e14;color:#fff;'><h2>NyxOS Code: <span style='color:#00f0ff;'>\(code)</span></h2></div>"
                            ]
                            
                            request.httpBody = try? JSONSerialization.data(withJSONObject: body)
                            
                            URLSession.shared.dataTask(with: request) { data, response, error in
                                if let error = error {
                                    print("[DIRECT RESEND ERROR]", error.localizedDescription)
                                }
                            }.resume()
                        }
                    })
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    
                    HStack(spacing: 10) {
                        Text("Authenticating...").font(.system(size: 8, weight: .bold, design: .monospaced)).foregroundColor(.yellow)
                        Spacer()
                    }
                    .padding(10)
                    .background(Color.white.opacity(0.1))
                }
                .background(Color.black)
                .clipShape(RoundedRectangle(cornerRadius: 24))
                .padding(20)
                .shadow(radius: 20)
                .zIndex(600)
            }
            
            if showEmailVerificationPopup {
                VStack(spacing: 12) {
                    Image(systemName: "envelope.badge.shield.half.filled")
                        .font(.system(size: 30))
                        .foregroundColor(viewModel.systemAccentColor)
                    
                    Text("Check Your Email Inbox")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(.white)
                    
                    Text("We've sent a 6-digit secure code to:\n\(pendingGoogleAccount)")
                        .font(.system(size: 8))
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                    
                    TextField("Enter 6-digit code from email", text: $enteredVerificationCode)
                        .font(.system(size: 10, design: .monospaced))
                        .padding(8)
                        .background(getBackgroundView(for: viewModel.osMode))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                    
                    HStack(spacing: 8) {
                        Button("Cancel") {
                            showEmailVerificationPopup = false
                            enteredVerificationCode = ""
                        }
                        .font(.system(size: 8, weight: .bold))
                        .frame(maxWidth: .infinity, minHeight: 28)
                        .background(Color.gray.opacity(0.3))
                        .foregroundColor(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                        
                        Button("Verify & Boot") {
                            if enteredVerificationCode.trimmingCharacters(in: .whitespacesAndNewlines) == generatedSecureCode {
                                audioEngine.playLockChime()
                                showEmailVerificationPopup = false
                                viewModel.login(provider: "Google: \(pendingGoogleAccount)")
                            } else {
                                audioEngine.playLockChime()
                                enteredVerificationCode = ""
                            }
                        }
                        .font(.system(size: 8, weight: .bold))
                        .frame(maxWidth: .infinity, minHeight: 28)
                        .background(viewModel.systemAccentColor)
                        .foregroundColor(.black)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                    }
                }
                .padding(14)
                .frame(width: 270)
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 18))
                .shadow(radius: 20)
                .zIndex(700)
            }
        }
        .background(Color(red: 0.03, green: 0.04, blue: 0.09).ignoresSafeArea())
    }
}

struct DiscordScrapingWebView: UIViewRepresentable {
    @Binding var url: URL
    var onUsernameFound: (String) -> Void
    
    func makeUIView(context: Context) -> WKWebView {
        let wv = WKWebView()
        wv.navigationDelegate = context.coordinator
        wv.load(URLRequest(url: url))
        return wv
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {
        if uiView.url != url { uiView.load(URLRequest(url: url)) }
    }
    
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    
    class Coordinator: NSObject, WKNavigationDelegate {
        let parent: DiscordScrapingWebView
        var timer: Timer?
        init(_ parent: DiscordScrapingWebView) { self.parent = parent }
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            timer?.invalidate()
            timer = Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { [weak webView] _ in
                guard let wv = webView else { return }
                let script = """
                (function() {
                    let userTag = document.querySelector('div[class*="globalName"], span[class*="username"]');
                    if (userTag) return userTag.innerText.trim();
                    return "";
                })();
                """
                wv.evaluateJavaScript(script) { res, _ in
                    if let uname = res as? String, !uname.isEmpty {
                        self.timer?.invalidate()
                        self.parent.onUsernameFound(uname)
                    }
                }
            }
        }
    }
}

struct GoogleScrapingWebView: UIViewRepresentable {
    @Binding var url: URL
    var onAccountFound: (String) -> Void
    
    func makeUIView(context: Context) -> WKWebView {
        let wv = WKWebView()
        wv.navigationDelegate = context.coordinator
        wv.load(URLRequest(url: url))
        return wv
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {
        if uiView.url != url { uiView.load(URLRequest(url: url)) }
    }
    
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    
    class Coordinator: NSObject, WKNavigationDelegate {
        let parent: GoogleScrapingWebView
        var timer: Timer?
        init(_ parent: GoogleScrapingWebView) { self.parent = parent }
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            timer?.invalidate()
            timer = Timer.scheduledTimer(withTimeInterval: 1.5, repeats: true) { [weak webView] _ in
                guard let wv = webView else { return }
                
                let script = """
                (function() {
                    let emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}/;
                    let profileIdentifier = document.querySelector('div[data-email], span[id="profile-identifier"]');
                    if (profileIdentifier) {
                        let val = profileIdentifier.getAttribute('data-email') || profileIdentifier.innerText;
                        let match = val.match(emailRegex);
                        if (match) return match[0];
                    }
                    let elements = document.querySelectorAll('input[type="email"], div, span, h1, h2, p');
                    for (let el of elements) {
                        let txt = (el.innerText || el.value || '');
                        let match = txt.match(emailRegex);
                        if (match) {
                            return match[0];
                        }
                    }
                    return "";
                })();
                """
                
                wv.evaluateJavaScript(script) { res, _ in
                    if let account = res as? String, !account.isEmpty {
                        self.timer?.invalidate()
                        self.parent.onAccountFound(account)
                    }
                }
            }
        }
    }
}

struct AppByAppOnboardingWizardView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    
    var body: some View {
        VStack(spacing: 16) {
            Spacer().frame(height: 15)
            
            let standardApps = NyxApp.allCases.filter { $0 != .nyxManager && $0 != .nyxSign }
            let currentApp = standardApps[min(viewModel.onboardingAppIndex, standardApps.count - 1)]
            let info = currentApp.onboardingInfo
            let localizedName = viewModel.currentLanguage.localizedAppName(currentApp)
            
            ZStack {
                Circle().fill(currentApp.accentColor.opacity(0.2)).frame(width: 75, height: 75)
                Image(systemName: currentApp.defaultIcon)
                    .font(.system(size: 32))
                    .foregroundColor(currentApp.accentColor)
            }
            
            VStack(spacing: 6) {
                Text("App Onboarding Guide (\(viewModel.onboardingAppIndex + 1) of \(standardApps.count))")
                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                    .foregroundColor(.gray)
                
                Text(localizedName)
                    .font(.system(size: 15, weight: .bold))
                    .foregroundColor(.white)
                
                Text(info.description)
                    .font(.system(size: 9))
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 24)
                
                Text(info.usageGuide)
                    .font(.system(size: 8, design: .monospaced))
                    .foregroundColor(.cyan)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 24)
                    .padding(.top, 2)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Key Capabilities:").font(.system(size: 8, weight: .bold)).foregroundColor(.white)
                ForEach(info.features, id: \.self) { feature in
                    HStack(spacing: 6) {
                        Circle().fill(currentApp.accentColor).frame(width: 4, height: 4)
                        Text(feature).font(.system(size: 8)).foregroundColor(.gray)
                    }
                }
            }
            .padding(10)
            .background(getBackgroundView(for: viewModel.osMode))
            .padding(.horizontal, 24)
            
            Spacer()
            
            HStack(spacing: 12) {
                if viewModel.onboardingAppIndex > 0 {
                    Button("Previous App") {
                        audioEngine.playClickHaptic()
                        viewModel.onboardingAppIndex -= 1
                    }
                    .font(.system(size: 9, weight: .bold))
                    .frame(maxWidth: .infinity, minHeight: 36)
                    .background(getBackgroundView(for: viewModel.osMode))
                    .foregroundColor(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                }
                
                Button(viewModel.onboardingAppIndex < standardApps.count - 1 ? "Next App Guide" : "Finish & Enter OS") {
                    audioEngine.playClickHaptic()
                    if viewModel.onboardingAppIndex < standardApps.count - 1 {
                        viewModel.onboardingAppIndex += 1
                    } else {
                        withAnimation {
                            viewModel.showAppByAppOnboarding = false
                        }
                    }
                }
                .font(.system(size: 9, weight: .bold))
                .frame(maxWidth: .infinity, minHeight: 36)
                .background(currentApp.accentColor)
                .foregroundColor(.black)
                .clipShape(RoundedRectangle(cornerRadius: 10))
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 25)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(red: 0.02, green: 0.03, blue: 0.08).ignoresSafeArea())
    }
}

struct HybridStatusBarView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    @ObservedObject var networkMonitor: RealNetworkMonitor
    
    var body: some View {
        HStack {
            Text(Date(), style: .time).font(.system(size: 11, weight: .bold, design: viewModel.osMode == .android ? .rounded : .default)).foregroundColor(viewModel.isLightMode ? .black : .white)
            
            Spacer()
            
            if !viewModel.hideDynamicIslandBadge {
                let isUtillityEnabled = viewModel.publishedTweaks.first(where: { $0.title == "Utillity" })?.isEnabled ?? false
                let badgeLabel = (viewModel.isJailbroken && !isUtillityEnabled) ? "ROOTED-NYX" : (viewModel.customStatusBarLabel.isEmpty ? viewModel.osMode.rawValue.uppercased() : viewModel.customStatusBarLabel)
                let badgeColor = (viewModel.isJailbroken && !isUtillityEnabled) ? Color.orange : viewModel.systemAccentColor
                
                if viewModel.osMode == .ios18 {
                    HStack(spacing: 6) {
                        Circle().fill(badgeColor).frame(width: 6, height: 6)
                            .shadow(color: badgeColor, radius: 4)
                        Text(badgeLabel)
                            .font(.system(size: 8, weight: .bold, design: .monospaced))
                            .foregroundColor(badgeColor)
                    }
                    .padding(.horizontal, 12).padding(.vertical, 5)
                    .background(.ultraThinMaterial)
                    .clipShape(Capsule())
                    .overlay(Capsule().stroke(Color.white.opacity(0.3), lineWidth: 1))
                    .shadow(color: badgeColor.opacity(0.25), radius: 6)
                    .onTapGesture {
                        audioEngine.playClickHaptic()
                        withAnimation { viewModel.isControlCenterOpen.toggle() }
                    }
                } else if viewModel.osMode == .android {
                    HStack(spacing: 5) {
                        Circle().fill(Color.black).frame(width: 8, height: 8)
                        Text(badgeLabel)
                            .font(.system(size: 7, weight: .bold, design: .monospaced))
                            .foregroundColor(badgeColor)
                    }
                    .padding(.horizontal, 8).padding(.vertical, 3)
                    .background(Color(red: 0.1, green: 0.12, blue: 0.11))
                    .clipShape(Capsule())
                    .overlay(Capsule().stroke(badgeColor.opacity(0.5), lineWidth: 1))
                    .onTapGesture {
                        audioEngine.playClickHaptic()
                        withAnimation { viewModel.isControlCenterOpen.toggle() }
                    }
                } else {
                    HStack(spacing: 6) {
                        Circle().fill(viewModel.isCpuOverclocked ? Color.red : badgeColor).frame(width: 6, height: 6)
                        Text(badgeLabel)
                            .font(.system(size: 8, weight: .bold, design: .monospaced))
                            .foregroundColor(viewModel.isCpuOverclocked ? Color.red : badgeColor)
                    }
                    .padding(.horizontal, 10).padding(.vertical, 4)
                    .background(getBackgroundView(for: viewModel.osMode))
                    .clipShape(Capsule())
                    .onTapGesture {
                        audioEngine.playClickHaptic()
                        withAnimation { viewModel.isControlCenterOpen.toggle() }
                    }
                }
            }
            
            Spacer()
            
            HStack(spacing: 6) {
                if viewModel.isRecordingScreen { Circle().fill(Color.red).frame(width: 6, height: 6) }
                
                HStack(spacing: 2) {
                    Text("\(Int(viewModel.batteryLevel * 100))%").font(.system(size: 7, weight: .bold)).foregroundColor(.gray)
                    Image(systemName: viewModel.isCharging ? "battery.100.bolt" : "battery.75")
                        .font(.system(size: 10))
                        .foregroundColor(viewModel.batteryLevel < 0.2 ? .red : .green)
                }
                
                Image(systemName: viewModel.wifiEnabled && networkMonitor.isConnected ? "wifi" : "wifi.slash")
                    .foregroundColor(viewModel.wifiEnabled && networkMonitor.isConnected ? viewModel.systemAccentColor : Color.red).font(.system(size: 10))
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 14)
    }
}

struct AndroidGestureNavBar: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    
    var body: some View {
        HStack {
            Button(action: {
                audioEngine.playClickHaptic()
                withAnimation {
                    if viewModel.showVirtualKeyboard { viewModel.showVirtualKeyboard = false }
                    else if viewModel.isControlCenterOpen { viewModel.isControlCenterOpen = false }
                    else if viewModel.isDesktopModeActive { viewModel.isDesktopModeActive = false }
                    else if viewModel.activeCustomAiApp != nil { viewModel.activeCustomAiApp = nil }
                    else if viewModel.activeSideloadGame != nil { viewModel.activeSideloadGame = nil }
                    else if viewModel.activeExeApp != nil { viewModel.activeExeApp = nil }
                    else if viewModel.activeStoreAppGame != nil { viewModel.activeStoreAppGame = nil }
                    else { viewModel.activeApp = nil }
                }
            }) {
                Image(systemName: viewModel.osMode == .android ? "triangle.fill" : "chevron.left")
                    .font(.system(size: viewModel.osMode == .android ? 11 : 14, weight: .bold))
                    .foregroundColor(viewModel.isLightMode ? .black.opacity(0.8) : .white.opacity(0.8))
            }
            Spacer()
            
            if viewModel.osMode == .android {
                HStack(spacing: 28) {
                    Circle().fill(Color.white.opacity(0.8)).frame(width: 8, height: 8)
                    Capsule().fill(viewModel.systemAccentColor).frame(width: 70, height: 4)
                    RoundedRectangle(cornerRadius: 1).fill(Color.white.opacity(0.8)).frame(width: 10, height: 10)
                }
                .onTapGesture {
                    audioEngine.playClickHaptic()
                    withAnimation {
                        viewModel.isControlCenterOpen = false
                        viewModel.showVirtualKeyboard = false
                        viewModel.activeApp = nil
                        viewModel.activeStoreAppGame = nil
                    }
                }
            } else {
                Capsule()
                    .fill(LinearGradient(colors: [viewModel.systemAccentColor.opacity(0.8), Color.white.opacity(0.8)], startPoint: .leading, endPoint: .trailing))
                    .frame(width: 100, height: 4)
                    .shadow(color: viewModel.systemAccentColor.opacity(0.5), radius: 4)
                    .onTapGesture {
                        audioEngine.playClickHaptic()
                        withAnimation {
                            viewModel.isControlCenterOpen = false
                            viewModel.showVirtualKeyboard = false
                            viewModel.isDesktopModeActive = false
                            viewModel.activeCustomAiApp = nil
                            viewModel.activeSideloadGame = nil
                            viewModel.activeExeApp = nil
                            viewModel.activeApp = nil
                            viewModel.activeStoreAppGame = nil
                        }
                    }
            }
            
            Spacer()
            Button(action: {
                audioEngine.playClickHaptic()
                withAnimation { viewModel.isControlCenterOpen.toggle() }
            }) {
                Image(systemName: viewModel.osMode == .android ? "square.fill" : "square.grid.2x2")
                    .font(.system(size: viewModel.osMode == .android ? 11 : 13, weight: .bold))
                    .foregroundColor(viewModel.isLightMode ? .black.opacity(0.8) : .white.opacity(0.8))
            }
        }
        .padding(.horizontal, 32)
        .padding(.bottom, 8)
        .background(getBackgroundView(for: viewModel.osMode))
    }
}

struct LockScreenView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    
    var body: some View {
        VStack {
            Spacer().frame(height: 50)
            VStack(spacing: 8) {
                Text(viewModel.osMode.rawValue.uppercased()).font(.system(size: 10, weight: .bold, design: .monospaced)).foregroundColor(viewModel.systemAccentColor)
                Text(Date(), style: .time).font(.system(size: 50, weight: .black, design: .rounded)).foregroundColor(viewModel.isLightMode ? .black : .white)
            }
            Spacer()
            Button(action: {
                audioEngine.playLockChime()
                viewModel.unlockDevice()
            }) {
                VStack(spacing: 12) {
                    Image(systemName: "lock.open.fill").font(.system(size: 24)).foregroundColor(viewModel.systemAccentColor)
                    Text(viewModel.currentLanguage.lockText).font(.system(size: 8, weight: .bold, design: .monospaced)).foregroundColor(.gray)
                }
                .padding(.horizontal, 20).padding(.vertical, 12)
                .background(.ultraThinMaterial)
                .clipShape(Capsule())
                .overlay(Capsule().stroke(viewModel.systemAccentColor.opacity(0.4), lineWidth: 1))
            }
            .padding(.bottom, 40)
        }
    }
}

struct HomeScreenView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    
    @State private var activeContextMenuApp: NyxApp? = nil
    @State private var orderedApps: [NyxApp] = NyxApp.allCases
    
    var body: some View {
        ZStack {
            VStack(spacing: 8) {
                Spacer().frame(height: 35)
                
                HStack {
                    Image(systemName: "magnifyingglass").foregroundColor(.gray).font(.system(size: 11))
                    TextField("Search App Library...", text: $viewModel.searchFilterText)
                        .font(.system(size: 10))
                        .foregroundColor(viewModel.isLightMode ? .black : .white)
                }
                .padding(8)
                .background(getBackgroundView(for: viewModel.osMode))
                .padding(.horizontal, 16)
                
                let allVisibleApps = getVisibleApps()
                let itemsPerPage = viewModel.isLandscape ? 10 : 12
                let columnCount = viewModel.isLandscape ? 5 : 3
                let pages = chunk(allVisibleApps, into: itemsPerPage)
                
                TabView {
                    ForEach(0..<max(1, pages.count), id: \.self) { pageIndex in
                        let pageApps = pages.indices.contains(pageIndex) ? pages[pageIndex] : []
                        
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 14), count: columnCount), spacing: 14) {
                            ForEach(pageApps) { appItem in
                                renderAppIcon(item: appItem)
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.top, 12)
                        .frame(maxHeight: .infinity, alignment: .top)
                    }
                }
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
                
                Spacer()
            }
            
            if let app = activeContextMenuApp {
                Color.black.opacity(0.4).ignoresSafeArea()
                    .onTapGesture { activeContextMenuApp = nil }
                    .zIndex(500)
                
                VStack(spacing: 6) {
                    Text(app.rawValue).font(.system(size: 11, weight: .bold)).foregroundColor(.white).padding(.bottom, 4)
                    
                    Button("Set Custom Icon") {
                        audioEngine.playClickHaptic()
                        viewModel.customAppIcons[app.rawValue] = "star.fill"
                        activeContextMenuApp = nil
                    }
                    .font(.system(size: 9, weight: .bold))
                    .frame(maxWidth: .infinity, minHeight: 30)
                    .background(Color.cyan.opacity(0.3))
                    .foregroundColor(.cyan)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                    
                    Button("Hide App") {
                        audioEngine.playClickHaptic()
                        viewModel.hiddenApps.insert(app.rawValue)
                        activeContextMenuApp = nil
                    }
                    .font(.system(size: 9, weight: .bold))
                    .frame(maxWidth: .infinity, minHeight: 30)
                    .background(Color.orange.opacity(0.3))
                    .foregroundColor(.orange)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                    
                    Button("Remove from Home Screen") {
                        audioEngine.playClickHaptic()
                        viewModel.deletedApps.insert(app.rawValue)
                        activeContextMenuApp = nil
                    }
                    .font(.system(size: 9, weight: .bold))
                    .frame(maxWidth: .infinity, minHeight: 30)
                    .background(Color.red.opacity(0.3))
                    .foregroundColor(.red)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                    
                    Button("Cancel") {
                        activeContextMenuApp = nil
                    }
                    .font(.system(size: 9))
                    .foregroundColor(.gray)
                    .padding(.top, 4)
                }
                .padding(16)
                .frame(width: 220)
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .shadow(radius: 20)
                .zIndex(510)
            }
        }
    }
    
    enum AppItemType {
        case standard(NyxApp)
        case customAi(CustomAIApp)
        case sideload(SideloaderGame)
        case store(StoreApp)
    }
    
    struct HomeAppIdentifier: Identifiable {
        let id = UUID()
        let type: AppItemType
        let rawKey: String
    }
    
    private func getVisibleApps() -> [HomeAppIdentifier] {
        var items: [HomeAppIdentifier] = []
        
        for app in orderedApps {
            let localizedName = viewModel.currentLanguage.localizedAppName(app)
            let matchesSearch = viewModel.searchFilterText.isEmpty || localizedName.localizedCaseInsensitiveContains(viewModel.searchFilterText)
            let isRootApp = (app == .nyxManager || app == .nyxSign)
            let allowedToShow: Bool = {
                if app == .nyxSign { return viewModel.showNyxSignUnlocked }
                if isRootApp { return viewModel.isJailbroken }
                return true
            }()
            
            if (app != .downloads || viewModel.showDownloadsAppUnlocked) &&
               allowedToShow &&
               (!viewModel.hiddenApps.contains(app.rawValue) || !viewModel.searchFilterText.isEmpty) &&
               !viewModel.deletedApps.contains(app.rawValue) &&
               matchesSearch {
                items.append(HomeAppIdentifier(type: .standard(app), rawKey: app.rawValue))
            }
        }
        
        for customApp in viewModel.customAiApps.filter({ $0.isDownloaded }) {
            let matchesSearch = viewModel.searchFilterText.isEmpty || customApp.name.localizedCaseInsensitiveContains(viewModel.searchFilterText)
            if matchesSearch {
                items.append(HomeAppIdentifier(type: .customAi(customApp), rawKey: customApp.name))
            }
        }
        
        for sideloadItem in viewModel.sideloadedGames.filter({ $0.isInstalledOnHomescreen }) {
            let matchesSearch = viewModel.searchFilterText.isEmpty || sideloadItem.title.localizedCaseInsensitiveContains(viewModel.searchFilterText)
            if matchesSearch {
                items.append(HomeAppIdentifier(type: .sideload(sideloadItem), rawKey: sideloadItem.title))
            }
        }
        
        for storeApp in viewModel.storeCatalog.filter({ $0.isInstalled }) {
            let matchesSearch = viewModel.searchFilterText.isEmpty || storeApp.name.localizedCaseInsensitiveContains(viewModel.searchFilterText)
            if matchesSearch {
                items.append(HomeAppIdentifier(type: .store(storeApp), rawKey: storeApp.name))
            }
        }
        
        return items
    }
    
    private func chunk(_ array: [HomeAppIdentifier], into size: Int) -> [[HomeAppIdentifier]] {
        stride(from: 0, to: array.count, by: size).map {
            Array(array[$0 ..< Swift.min($0 + size, array.count)])
        }
    }
    
    @ViewBuilder
    private func renderAppIcon(item: HomeAppIdentifier) -> some View {
        switch item.type {
        case .standard(let app):
            let localizedName = viewModel.currentLanguage.localizedAppName(app)
            let iconToUse = viewModel.customAppIcons[app.rawValue] ?? app.defaultIcon
            Button(action: {
                audioEngine.playClickHaptic()
                withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) { viewModel.activeApp = app }
            }) {
                VStack(spacing: 3) {
                    ZStack {
                        RoundedRectangle(cornerRadius: viewModel.osMode == .android ? 18 : 14)
                            .fill(getBackgroundShapeStyle(for: viewModel.osMode == .ios18 ? .ios18 : .android))
                            .frame(width: 48, height: 48)
                            .overlay(
                                RoundedRectangle(cornerRadius: viewModel.osMode == .android ? 18 : 14)
                                    .stroke(
                                        LinearGradient(colors: [app.accentColor.opacity(0.8), .white.opacity(0.4)], startPoint: .topLeading, endPoint: .bottomTrailing),
                                        lineWidth: viewModel.osMode == .ios18 ? 1.5 : 1.0
                                    )
                            )
                            .shadow(color: app.accentColor.opacity(viewModel.osMode == .ios18 ? 0.5 : 0.35), radius: viewModel.osMode == .ios18 ? 8 : 6, x: 0, y: 3)
                        
                        Image(systemName: iconToUse)
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundColor(app.accentColor)
                            .shadow(color: app.accentColor.opacity(0.6), radius: 4)
                    }
                    Text(localizedName)
                        .font(.system(size: 8, weight: .medium))
                        .foregroundColor(viewModel.isLightMode ? .black : .white)
                        .lineLimit(1)
                        .frame(width: 70)
                }
            }
            .buttonStyle(ScaleButtonStyle())
            .simultaneousGesture(
                LongPressGesture(minimumDuration: 0.5).onEnded { _ in
                    audioEngine.playClickHaptic()
                    activeContextMenuApp = app
                }
            )
            
        case .customAi(let customApp):
            Button(action: {
                audioEngine.playClickHaptic()
                withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) { viewModel.activeCustomAiApp = customApp }
            }) {
                VStack(spacing: 3) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 14)
                            .fill(getBackgroundShapeStyle(for: viewModel.osMode == .ios18 ? .ios18 : .android))
                            .frame(width: 48, height: 48)
                            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.cyan.opacity(0.6), lineWidth: 1.5))
                            .shadow(color: Color.cyan.opacity(0.4), radius: 6)
                        Image(systemName: customApp.icon)
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundColor(.cyan)
                    }
                    Text(customApp.name)
                        .font(.system(size: 8, weight: .medium))
                        .foregroundColor(viewModel.isLightMode ? .black : .white)
                        .lineLimit(1)
                        .frame(width: 70)
                }
            }
            .buttonStyle(ScaleButtonStyle())
            
        case .sideload(let sideloadItem):
            Button(action: {
                audioEngine.playClickHaptic()
                withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) { viewModel.activeSideloadGame = sideloadItem }
            }) {
                VStack(spacing: 3) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 14)
                            .fill(getBackgroundShapeStyle(for: viewModel.osMode == .ios18 ? .ios18 : .android))
                            .frame(width: 48, height: 48)
                            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.red.opacity(0.6), lineWidth: 1.5))
                            .shadow(color: Color.red.opacity(0.4), radius: 6)
                        Image(systemName: "gamecontroller.fill")
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundColor(.red)
                    }
                    Text(sideloadItem.title)
                        .font(.system(size: 8, weight: .medium))
                        .foregroundColor(viewModel.isLightMode ? .black : .white)
                        .lineLimit(1)
                        .frame(width: 70)
                }
            }
            .buttonStyle(ScaleButtonStyle())
            
        case .store(let storeApp):
            Button(action: {
                audioEngine.playClickHaptic()
                if storeApp.isGame { viewModel.activeStoreAppGame = storeApp }
                else if storeApp.isExeApp { viewModel.activeExeApp = storeApp }
            }) {
                VStack(spacing: 3) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 14)
                            .fill(getBackgroundShapeStyle(for: viewModel.osMode == .ios18 ? .ios18 : .android))
                            .frame(width: 48, height: 48)
                            .overlay(RoundedRectangle(cornerRadius: 14).stroke(storeApp.accent.opacity(0.6), lineWidth: 1.5))
                            .shadow(color: storeApp.accent.opacity(0.4), radius: 6)
                        Image(systemName: storeApp.icon)
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundColor(storeApp.accent)
                    }
                    Text(storeApp.name)
                        .font(.system(size: 8, weight: .medium))
                        .foregroundColor(viewModel.isLightMode ? .black : .white)
                        .lineLimit(1)
                        .frame(width: 70)
                }
            }
            .buttonStyle(ScaleButtonStyle())
        }
    }
}

struct ScaleButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.92 : 1.0)
            .animation(.spring(response: 0.2, dampingFraction: 0.5), value: configuration.isPressed)
    }
}

struct ComputerDesktopEnvironmentView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    @ObservedObject var networkMonitor: RealNetworkMonitor
    
    @State private var openWindows: [WindowItem] = []
    @State private var showStartMenu: Bool = false
    @State private var mousePosition: CGPoint = CGPoint(x: 180, y: 250)
    @State private var showVirtualKeyboard: Bool = false
    @State private var lastDragLocation: CGSize = .zero
    
    var body: some View {
        VStack(spacing: 0) {
            ZStack {
                Group {
                    if viewModel.osMode == .linux {
                        LinearGradient(colors: [Color(red: 0.08, green: 0.05, blue: 0.15), Color.black], startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
                    } else {
                        LinearGradient(colors: [Color(red: 0.04, green: 0.12, blue: 0.28), Color(red: 0.02, green: 0.04, blue: 0.08)], startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
                    }
                }
                
                ScrollView {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: viewModel.isLandscape ? 4 : 2), spacing: 12) {
                        let desktopApps = NyxApp.allCases.filter { app in
                            let isRootApp = (app == .nyxManager || app == .nyxSign)
                            let allowed: Bool = {
                                if app == .nyxSign { return viewModel.showNyxSignUnlocked }
                                if isRootApp { return viewModel.isJailbroken }
                                return true
                            }()
                            return allowed
                        }
                        
                        ForEach(desktopApps, id: \.self) { app in
                            Button(action: {
                                audioEngine.playClickHaptic()
                                openAppWindow(app)
                            }) {
                                VStack(spacing: 3) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 12)
                                            .fill(getBackgroundShapeStyle(for: viewModel.osMode == .ios18 ? .ios18 : .android))
                                            .frame(width: 38, height: 38)
                                            .overlay(RoundedRectangle(cornerRadius: 12).stroke(app.accentColor.opacity(0.6), lineWidth: 1.2))
                                            .shadow(color: app.accentColor.opacity(0.3), radius: 4)
                                        Image(systemName: app.defaultIcon)
                                            .font(.system(size: 15))
                                            .foregroundColor(app.accentColor)
                                    }
                                    Text(app.rawValue)
                                        .font(.system(size: 7, weight: .bold))
                                        .foregroundColor(.white)
                                        .lineLimit(1)
                                        .frame(width: 65)
                                        .shadow(radius: 2)
                                }
                            }
                            .buttonStyle(ScaleButtonStyle())
                        }
                    }
                    .padding(.top, 35)
                    .padding(.horizontal, 12)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                
                ForEach($openWindows) { $win in
                    VStack(spacing: 0) {
                        HStack {
                            Image(systemName: win.app.defaultIcon).font(.system(size: 9)).foregroundColor(win.app.accentColor)
                            Text(viewModel.currentLanguage.localizedAppName(win.app)).font(.system(size: 8, weight: .bold)).foregroundColor(.white)
                            Spacer()
                            
                            Button(action: {
                                audioEngine.playClickHaptic()
                                withAnimation {
                                    win.size = win.size.width < 230 ? CGSize(width: 280, height: 230) : CGSize(width: 170, height: 130)
                                }
                            }) {
                                Image(systemName: "square.fill").font(.system(size: 7)).foregroundColor(.gray)
                            }
                            
                            Button(action: {
                                audioEngine.playClickHaptic()
                                openWindows.removeAll(where: { $0.id == win.id })
                            }) {
                                Image(systemName: "xmark").font(.system(size: 8, weight: .bold)).foregroundColor(.white)
                            }
                        }
                        .padding(6)
                        .background(getBackgroundView(for: viewModel.osMode))
                        .contentShape(Rectangle())
                        .gesture(
                            DragGesture()
                                .onChanged { value in
                                    win.position = CGPoint(x: win.position.x + value.translation.width, y: win.position.y + value.translation.height)
                                }
                        )
                        
                        AppContainerView(app: win.app, viewModel: viewModel, audioEngine: audioEngine, networkMonitor: networkMonitor)
                    }
                    .frame(width: win.size.width, height: win.size.height)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(win.app.accentColor.opacity(0.8), lineWidth: 1.5))
                    .shadow(color: win.app.accentColor.opacity(0.25), radius: 15)
                    .position(win.position)
                }
                
                VStack {
                    Spacer()
                    HStack(spacing: 8) {
                        Button(action: {
                            audioEngine.playClickHaptic()
                            withAnimation { showStartMenu.toggle() }
                        }) {
                            HStack(spacing: 4) {
                                Image(systemName: viewModel.osMode == .linux ? "terminal.fill" : "square.grid.2x2.fill")
                                    .font(.system(size: 11))
                                    .foregroundColor(viewModel.systemAccentColor)
                                Text(viewModel.osMode == .linux ? "Linux" : "Start")
                                    .font(.system(size: 8, weight: .bold))
                                    .foregroundColor(.white)
                            }
                            .padding(.horizontal, 10).padding(.vertical, 6)
                            .background(getBackgroundView(for: viewModel.osMode))
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                            .overlay(RoundedRectangle(cornerRadius: 8).stroke(viewModel.systemAccentColor.opacity(0.4), lineWidth: 1))
                        }
                        
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 4) {
                                ForEach(openWindows) { win in
                                    Button(action: {
                                        audioEngine.playClickHaptic()
                                    }) {
                                        HStack(spacing: 4) {
                                            Image(systemName: win.app.defaultIcon).font(.system(size: 8)).foregroundColor(win.app.accentColor)
                                            Text(win.app.rawValue).font(.system(size: 7, weight: .bold)).foregroundColor(.white)
                                        }
                                        .padding(.horizontal, 8).padding(.vertical, 5)
                                        .background(getBackgroundView(for: viewModel.osMode))
                                        .clipShape(RoundedRectangle(cornerRadius: 6))
                                    }
                                }
                            }
                        }
                        
                        Spacer()
                        
                        HStack(spacing: 6) {
                            Button(action: { audioEngine.playClickHaptic(); showVirtualKeyboard.toggle() }) {
                                Image(systemName: "keyboard").font(.system(size: 12)).foregroundColor(showVirtualKeyboard ? Color.cyan : Color.white)
                            }
                            
                            Text(Date(), style: .time)
                                .font(.system(size: 8, weight: .bold, design: .monospaced))
                                .foregroundColor(.white)
                            
                            Button(action: {
                                audioEngine.playClickHaptic()
                                viewModel.isDesktopModeActive = false
                                viewModel.osMode = viewModel.isJailbroken ? .ios18 : .nyx
                            }) {
                                Image(systemName: "power.circle.fill")
                                    .font(.system(size: 14))
                                    .foregroundColor(.red)
                            }
                        }
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(getBackgroundView(for: viewModel.osMode))
                }
                
                Image(systemName: "cursorarrow")
                    .font(.system(size: 14))
                    .foregroundColor(.white)
                    .shadow(radius: 2)
                    .position(mousePosition)
                    .allowsHitTesting(false)
                
                if showStartMenu {
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Image(systemName: "desktopcomputer").foregroundColor(viewModel.systemAccentColor)
                            Text(viewModel.osMode.rawValue.uppercased()).font(.system(size: 9, weight: .bold)).foregroundColor(.white)
                            Spacer()
                            Button("Close") { showStartMenu = false }.font(.system(size: 8, weight: .bold)).foregroundColor(.red)
                        }
                        .padding(.bottom, 4)
                        
                        ScrollView {
                            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 6) {
                                let availableApps = NyxApp.allCases.filter { app in
                                    let isRootApp = (app == .nyxManager || app == .nyxSign)
                                    let allowed: Bool = {
                                        if app == .nyxSign { return viewModel.showNyxSignUnlocked }
                                        if isRootApp { return viewModel.isJailbroken }
                                        return true
                                    }()
                                    return allowed
                                }
                                
                                ForEach(availableApps) { app in
                                    Button(action: {
                                        audioEngine.playClickHaptic()
                                        openAppWindow(app)
                                        showStartMenu = false
                                    }) {
                                        HStack(spacing: 6) {
                                            Image(systemName: app.defaultIcon).foregroundColor(app.accentColor).font(.system(size: 10))
                                            Text(app.rawValue).font(.system(size: 8, weight: .bold)).foregroundColor(.white)
                                        }
                                        .padding(8)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        .background(getBackgroundView(for: viewModel.osMode))
                                        .clipShape(RoundedRectangle(cornerRadius: 8))
                                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(app.accentColor.opacity(0.3), lineWidth: 1))
                                    }
                                }
                            }
                        }
                        .frame(height: 220)
                    }
                    .padding(12)
                    .frame(width: 270)
                    .background(getBackgroundView(for: viewModel.osMode))
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .shadow(radius: 20)
                    .position(x: 140, y: 290)
                    .zIndex(300)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 32))
            
            HStack(spacing: 12) {
                HStack(spacing: 8) {
                    Image(systemName: "hand.point.up.braille.fill")
                        .font(.system(size: 14))
                        .foregroundColor(viewModel.systemAccentColor)
                    Text("TRACKPAD")
                        .font(.system(size: 8, weight: .bold, design: .monospaced))
                        .foregroundColor(.white)
                }
                
                Spacer()
                
                Button(action: {
                    audioEngine.playClickHaptic()
                    simulateMouseClick(at: mousePosition)
                }) {
                    HStack(spacing: 4) {
                        Image(systemName: "cursorarrow.click").font(.system(size: 10))
                        Text("CLICK").font(.system(size: 8, weight: .bold))
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .background(viewModel.systemAccentColor)
                    .foregroundColor(.black)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                    .shadow(color: viewModel.systemAccentColor.opacity(0.4), radius: 6)
                }
            }
            .padding(.horizontal, 16)
            .frame(width: viewModel.isLandscape ? 600 : 360, height: 50)
            .background(getBackgroundView(for: viewModel.osMode))
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(viewModel.systemAccentColor.opacity(0.4), lineWidth: 1))
            .padding(.top, 10)
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        let deltaX = value.translation.width - lastDragLocation.width
                        let deltaY = value.translation.height - lastDragLocation.height
                        lastDragLocation = value.translation
                        
                        let maxX: CGFloat = viewModel.isLandscape ? 585 : 345
                        let maxY: CGFloat = viewModel.isLandscape ? 335 : 575
                        mousePosition = CGPoint(
                            x: min(max(15, mousePosition.x + deltaX), maxX),
                            y: min(max(20, mousePosition.y + deltaY), maxY)
                        )
                    }
                    .onEnded { _ in
                        lastDragLocation = .zero
                    }
            )
        }
    }
    
    private func openAppWindow(_ app: NyxApp) {
        if !openWindows.contains(where: { $0.app == app }) {
            openWindows.append(WindowItem(app: app, position: CGPoint(x: CGFloat.random(in: 130...190), y: CGFloat.random(in: 120...240)), size: CGSize(width: 260, height: 210)))
        }
    }
    
    private func simulateMouseClick(at point: CGPoint) {
        if point.x >= 15 && point.x <= 95 && point.y >= 520 && point.y <= 570 {
            withAnimation { showStartMenu.toggle() }
            return
        }
        
        if showStartMenu && point.x >= 20 && point.x <= 270 && point.y >= 160 && point.y <= 420 {
            let availableApps = NyxApp.allCases.filter { app in
                let isRootApp = (app == .nyxManager || app == .nyxSign)
                let allowed: Bool = {
                    if app == .nyxSign { return viewModel.showNyxSignUnlocked }
                    if isRootApp { return viewModel.isJailbroken }
                    return true
                }()
                return allowed
            }
            let index = Int((point.y - 180) / 45) * 2 + (point.x < 145 ? 0 : 1)
            if index >= 0 && index < availableApps.count {
                openAppWindow(availableApps[index])
                showStartMenu = false
            }
            return
        }
        
        for i in 0..<openWindows.count {
            let win = openWindows[i]
            let halfW = win.size.width / 2
            let halfH = win.size.height / 2
            let minX = win.position.x - halfW
            let maxX = win.position.x + halfW
            let minY = win.position.y - halfH
            let maxY = win.position.y + halfH
            
            if point.x >= minX && point.x <= maxX && point.y >= minY && point.y <= maxY {
                if point.y <= minY + 30 {
                    if point.x >= maxX - 25 {
                        openWindows.remove(at: i)
                        return
                    } else if point.x >= maxX - 50 {
                        withAnimation {
                            openWindows[i].size = openWindows[i].size.width < 230 ? CGSize(width: 280, height: 230) : CGSize(width: 170, height: 130)
                        }
                        return
                    }
                }
            }
        }
        
        let desktopApps = NyxApp.allCases.filter { app in
            let isRootApp = (app == .nyxManager || app == .nyxSign)
            let allowed: Bool = {
                if app == .nyxSign { return viewModel.showNyxSignUnlocked }
                if isRootApp { return viewModel.isJailbroken }
                return true
            }()
            return allowed
        }
        
        if point.y >= 40 && point.y <= 320 {
            let col = point.x < 180 ? 0 : 1
            let row = Int((point.y - 40) / 75)
            let index = row * 2 + col
            if index >= 0 && index < desktopApps.count {
                openAppWindow(desktopApps[index])
            }
        }
    }
}

struct AppContainerView: View {
    let app: NyxApp
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    @ObservedObject var networkMonitor: RealNetworkMonitor
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text(viewModel.currentLanguage.localizedAppName(app).uppercased()).font(.system(size: 10, weight: .bold, design: .monospaced)).foregroundColor(app.accentColor)
                Spacer()
                Button(action: {
                    audioEngine.playClickHaptic()
                    withAnimation { viewModel.activeApp = nil }
                }) {
                    Image(systemName: "xmark.circle.fill").foregroundColor(.gray)
                }
            }
            .padding(8)
            .background(getBackgroundView(for: viewModel.osMode))
            
            Group {
                switch app {
                case .browser: HorizonWebBrowserView(viewModel: viewModel, networkMonitor: networkMonitor)
                case .photos: NativePhotosAppView(viewModel: viewModel, audioEngine: audioEngine)
                case .weather: WeatherAppView(viewModel: viewModel, networkMonitor: networkMonitor)
                case .locations: LocationsAppView(viewModel: viewModel, networkMonitor: networkMonitor)
                case .aether: AetherToolsetView(viewModel: viewModel)
                case .store: NyxAppStoreView(viewModel: viewModel, audioEngine: audioEngine)
                case .vault: VaultAppView(viewModel: viewModel, audioEngine: audioEngine)
                case .prism: PrismAppView(viewModel: viewModel, audioEngine: audioEngine)
                case .settings: SettingsAppView(viewModel: viewModel, networkMonitor: networkMonitor)
                case .downloads: DownloadsAppView(viewModel: viewModel, audioEngine: audioEngine)
                case .nyxManager: NyxManagerTweakAppView(viewModel: viewModel, audioEngine: audioEngine)
                case .nyxSign: NyxSignStoreView(viewModel: viewModel, audioEngine: audioEngine)
                case .saveCodes: SaveCodesAppView(viewModel: viewModel, audioEngine: audioEngine)
                case .qiblaTracker: QiblaTrackerAppView(viewModel: viewModel, networkMonitor: networkMonitor)
                case .notesApp: NotesAppView(viewModel: viewModel, audioEngine: audioEngine)
                case .calculatorApp: CalculatorAppView(viewModel: viewModel, audioEngine: audioEngine)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .background(viewModel.osMode == .ios18 ? AnyView(Color.clear.background(.ultraThinMaterial)) : AnyView(viewModel.isLightMode ? Color(white: 0.95) : Color(red: 0.04, green: 0.04, blue: 0.08)))
        .clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(app.accentColor.opacity(0.4), lineWidth: 1))
    }
}

struct WeatherAppView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var networkMonitor: RealNetworkMonitor
    
    var body: some View {
        VStack(spacing: 16) {
            Spacer().frame(height: 10)
            Image(systemName: "cloud.sun.fill").font(.system(size: 55)).foregroundColor(.yellow)
            Text("Local Environment").font(.system(size: 14, weight: .bold)).foregroundColor(viewModel.isLightMode ? .black : .white)
            Text("32°C").font(.system(size: 40, weight: .black, design: .rounded)).foregroundColor(viewModel.isLightMode ? .black : .white)
            Text("Sunny & Clear Conditions").font(.system(size: 10)).foregroundColor(.gray)
            
            VStack(spacing: 8) {
                HStack {
                    Text("Network Status: \(networkMonitor.connectionType)").font(.system(size: 9))
                    Spacer()
                    Text("Link: Active").font(.system(size: 9))
                }
                HStack {
                    Text("GPS Track: Synced").font(.system(size: 9))
                    Spacer()
                    Text("UV Index: 6 High").font(.system(size: 9))
                }
            }
            .padding(12)
            .background(getBackgroundView(for: viewModel.osMode))
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.white.opacity(0.15), lineWidth: 1))
            .padding(.horizontal, 20)
            
            Spacer()
        }
    }
}

struct LocationsAppView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var networkMonitor: RealNetworkMonitor
    
    var body: some View {
        VStack(spacing: 14) {
            Spacer().frame(height: 10)
            Image(systemName: "location.fill").font(.system(size: 45)).foregroundColor(.teal)
            Text("GPS Location & Environment").font(.system(size: 12, weight: .bold)).foregroundColor(viewModel.isLightMode ? .black : .white)
            
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Image(systemName: "mappin.and.ellipse").foregroundColor(.teal)
                    VStack(alignment: .leading) {
                        Text("Active Location Vector").font(.system(size: 11, weight: .bold)).foregroundColor(viewModel.isLightMode ? .black : .white)
                        Text(networkMonitor.deviceCoordinates).font(.system(size: 8, design: .monospaced)).foregroundColor(.cyan)
                    }
                }
                .padding(10)
                .background(getBackgroundView(for: viewModel.osMode))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.teal.opacity(0.3), lineWidth: 1))
            }
            .padding(.horizontal, 16)
            
            Button("Refresh Location Sync") {}
            .font(.system(size: 9, weight: .bold))
            .padding(.horizontal, 14).padding(.vertical, 6)
            .background(Color.teal)
            .foregroundColor(.white)
            .clipShape(Capsule())
            
            Spacer()
        }
    }
}

struct NotesAppView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    @State private var noteTitle: String = ""
    @State private var noteBody: String = ""
    @State private var savedNotes: [String] = ["Welcome to Nyx Notes!", "System Kernel is healthy."]
    
    var body: some View {
        VStack(spacing: 10) {
            TextField("Note Title...", text: $noteTitle)
                .font(.system(size: 10, weight: .bold))
                .padding(8)
                .background(getBackgroundView(for: viewModel.osMode))
                .clipShape(RoundedRectangle(cornerRadius: 8))
                .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.white.opacity(0.2), lineWidth: 1))
                .foregroundColor(.white)
                .padding(.horizontal, 12)
            
            TextField("Type your note here...", text: $noteBody)
                .font(.system(size: 10))
                .padding(8)
                .background(getBackgroundView(for: viewModel.osMode))
                .clipShape(RoundedRectangle(cornerRadius: 8))
                .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.white.opacity(0.2), lineWidth: 1))
                .foregroundColor(.white)
                .padding(.horizontal, 12)
            
            Button("Save Note") {
                audioEngine.playClickHaptic()
                if !noteTitle.isEmpty {
                    savedNotes.append("\(noteTitle): \(noteBody)")
                    noteTitle = ""
                    noteBody = ""
                }
            }
            .font(.system(size: 9, weight: .bold))
            .padding(6)
            .background(Color.yellow)
            .foregroundColor(.black)
            .clipShape(Capsule())
            
            List {
                ForEach(savedNotes, id: \.self) { note in
                    Text(note).font(.system(size: 9)).foregroundColor(.white)
                }
            }
            .listStyle(PlainListStyle())
        }
        .padding(.top, 8)
    }
}

struct CalculatorAppView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    @State private var displayValue: String = "0"
    @State private var currentOperation: String = ""
    @State private var firstOperand: Double = 0
    
    var body: some View {
        VStack(spacing: 8) {
            HStack {
                Spacer()
                Text(displayValue)
                    .font(.system(size: 28, weight: .bold, design: .monospaced))
                    .foregroundColor(.white)
            }
            .padding(12)
            .background(getBackgroundView(for: viewModel.osMode))
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.white.opacity(0.2), lineWidth: 1))
            .padding(.horizontal, 12)
            
            let buttons = [
                ["7", "8", "9", "/"],
                ["4", "5", "6", "*"],
                ["1", "2", "3", "-"],
                ["C", "0", "=", "+"]
            ]
            
            ForEach(buttons, id: \.self) { row in
                HStack(spacing: 8) {
                    ForEach(row, id: \.self) { btn in
                        Button(action: {
                            audioEngine.playClickHaptic()
                            handleButtonPress(btn)
                        }) {
                            Text(btn)
                                .font(.system(size: 12, weight: .bold))
                                .frame(maxWidth: .infinity, minHeight: 32)
                                .background(getBackgroundView(for: viewModel.osMode))
                                .foregroundColor(.white)
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                                .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.white.opacity(0.2), lineWidth: 1))
                        }
                    }
                }
                .padding(.horizontal, 12)
            }
            Spacer()
        }
        .padding(.top, 10)
    }
    
    private func handleButtonPress(_ btn: String) {
        if btn == "C" {
            displayValue = "0"
            firstOperand = 0
            currentOperation = ""
        } else if let _ = Double(btn) {
            if displayValue == "0" { displayValue = btn }
            else { displayValue += btn }
        } else if btn == "=" {
            if let val = Double(displayValue) {
                if currentOperation == "+" { displayValue = "\(firstOperand + val)" }
                else if currentOperation == "-" { displayValue = "\(firstOperand - val)" }
                else if currentOperation == "*" { displayValue = "\(firstOperand * val)" }
                else if currentOperation == "/" { displayValue = val != 0 ? "\(firstOperand / val)" : "Error" }
            }
        } else {
            if let val = Double(displayValue) {
                firstOperand = val
                currentOperation = btn
                displayValue = "0"
            }
        }
    }
}

struct QiblaTrackerAppView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var networkMonitor: RealNetworkMonitor
    
    var body: some View {
        VStack(spacing: 14) {
            Spacer().frame(height: 10)
            Image(systemName: "safari.fill").font(.system(size: 50)).foregroundColor(.green)
            Text("Qibla Direction Compass").font(.system(size: 12, weight: .bold)).foregroundColor(.white)
            Text("Bearing to Mecca (Kaaba): 142.5° SE").font(.system(size: 9, design: .monospaced)).foregroundColor(.green)
            
            VStack(spacing: 6) {
                Text("GPS Status: Accurate").font(.system(size: 9)).foregroundColor(.gray)
                Text(networkMonitor.deviceCoordinates).font(.system(size: 8, design: .monospaced)).foregroundColor(.cyan)
            }
            .padding(10)
            .background(getBackgroundView(for: viewModel.osMode))
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.green.opacity(0.3), lineWidth: 1))
            .padding(.horizontal, 16)
            
            Spacer()
        }
    }
}

struct VaultAppView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    
    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                Text("VAULT SECURE STORAGE").font(.system(size: 10, weight: .bold, design: .monospaced)).foregroundColor(Color.purple)
                
                ForEach(viewModel.vaultNotes) { note in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(note.title).font(.system(size: 10, weight: .bold)).foregroundColor(.white)
                        Text(note.content).font(.system(size: 9, design: .monospaced)).foregroundColor(.gray)
                    }
                    .padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(getBackgroundView(for: viewModel.osMode))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.purple.opacity(0.3), lineWidth: 1))
                    .padding(.horizontal, 16)
                }
            }
            .padding(.top, 10)
        }
    }
}

struct DownloadsAppView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    
    var body: some View {
        VStack(spacing: 10) {
            Text("SYSTEM DOWNLOADS & FILES").font(.system(size: 10, weight: .bold)).foregroundColor(.blue)
            Text("Tap any downloaded file to install or open it.").font(.system(size: 8)).foregroundColor(.gray)
            
            List {
                ForEach(viewModel.downloadedFiles) { item in
                    Button(action: {
                        audioEngine.playClickHaptic()
                        viewModel.openDownloadedFile(item: item)
                    }) {
                        HStack {
                            Image(systemName: item.filename.hasSuffix(".mp4") ? "video.fill" : "doc.fill").foregroundColor(.blue)
                            VStack(alignment: .leading) {
                                Text(item.filename).font(.system(size: 9, weight: .bold)).foregroundColor(.white)
                                Text("\(item.filesize) • Tap to open/install").font(.system(size: 7)).foregroundColor(.cyan)
                            }
                            Spacer()
                            Image(systemName: "chevron.right").font(.system(size: 8)).foregroundColor(.gray)
                        }
                        .padding(4)
                    }
                }
            }
            .listStyle(PlainListStyle())
        }
        .padding(.top, 8)
    }
}

struct NyxSignStoreView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    
    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                Text("NYXSIGN SIDELOADER PORTAL").font(.system(size: 10, weight: .bold)).foregroundColor(.red)
                Text("Sign and install custom IPA/APK packages securely.").font(.system(size: 9)).foregroundColor(.gray)
                
                ForEach($viewModel.sideloadedGames) { $game in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(game.title).font(.system(size: 10, weight: .bold)).foregroundColor(.white)
                            Text("\(game.format) • \(game.size)").font(.system(size: 8)).foregroundColor(.gray)
                        }
                        Spacer()
                        Button(game.isInstalledOnHomescreen ? "Installed" : "Install") {
                            audioEngine.playClickHaptic()
                            viewModel.sideloadAndInstallGame(id: game.id)
                        }
                        .font(.system(size: 8, weight: .bold))
                        .padding(.horizontal, 10).padding(.vertical, 4)
                        .background(game.isInstalledOnHomescreen ? Color.green.opacity(0.3) : Color.red)
                        .foregroundColor(.white)
                        .clipShape(Capsule())
                    }
                    .padding(10)
                    .background(getBackgroundView(for: viewModel.osMode))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.red.opacity(0.3), lineWidth: 1))
                    .padding(.horizontal, 16)
                }
            }
            .padding(.top, 10)
        }
    }
}

struct NyxManagerTweakAppView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    @State private var newTweakTitle: String = ""
    @State private var newTweakDesc: String = ""
    
    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                Text("NYXMANAGER TWEAK REPOSITORY").font(.system(size: 10, weight: .bold, design: .monospaced)).foregroundColor(.orange)
                Text("Enable or disable active system jailbreak hooks and tweaks.").font(.system(size: 9)).foregroundColor(.gray)
                
                ForEach($viewModel.publishedTweaks) { $tweak in
                    HStack {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(tweak.title).font(.system(size: 10, weight: .bold)).foregroundColor(.white)
                            Text(tweak.description).font(.system(size: 8)).foregroundColor(.gray)
                            Text("By \(tweak.author)").font(.system(size: 7, design: .monospaced)).foregroundColor(.orange)
                        }
                        Spacer()
                        Toggle("", isOn: $tweak.isEnabled)
                            .labelsHidden()
                            .onChange(of: tweak.isEnabled) { oldValue, newValue in
                                audioEngine.playClickHaptic()
                            }
                    }
                    .padding(10)
                    .background(getBackgroundView(for: viewModel.osMode))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.orange.opacity(0.3), lineWidth: 1))
                    .padding(.horizontal, 16)
                }
                
                VStack(spacing: 8) {
                    Text("Publish Custom Tweak").font(.system(size: 9, weight: .bold)).foregroundColor(.white)
                    TextField("Tweak Title", text: $newTweakTitle)
                        .font(.system(size: 9))
                        .padding(6)
                        .background(getBackgroundView(for: viewModel.osMode))
                        .clipShape(RoundedRectangle(cornerRadius: 6))
                        .foregroundColor(.white)
                    
                    TextField("Description", text: $newTweakDesc)
                        .font(.system(size: 9))
                        .padding(6)
                        .background(getBackgroundView(for: viewModel.osMode))
                        .clipShape(RoundedRectangle(cornerRadius: 6))
                        .foregroundColor(.white)
                    
                    Button("Publish Tweak") {
                        audioEngine.playClickHaptic()
                        if !newTweakTitle.isEmpty {
                            viewModel.publishCustomTweak(title: newTweakTitle, desc: newTweakDesc)
                            newTweakTitle = ""
                            newTweakDesc = ""
                        }
                    }
                    .font(.system(size: 9, weight: .bold))
                    .padding(.horizontal, 12).padding(.vertical, 6)
                    .background(Color.orange)
                    .foregroundColor(.black)
                    .clipShape(Capsule())
                }
                .padding(12)
                .background(getBackgroundView(for: viewModel.osMode))
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.orange.opacity(0.3), lineWidth: 1))
                .padding(.horizontal, 16)
            }
            .padding(.top, 10)
        }
    }
}

struct NyxAppStoreView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    
    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                Text("APP STORE CATALOG").font(.system(size: 10, weight: .bold)).foregroundColor(.orange)
                
                ForEach(viewModel.storeCatalog) { app in
                    HStack {
                        Image(systemName: app.icon).foregroundColor(app.accent).font(.system(size: 22))
                        VStack(alignment: .leading) {
                            Text(app.name).font(.system(size: 11, weight: .bold)).foregroundColor(.white)
                            Text(app.description).font(.system(size: 8)).foregroundColor(.gray)
                        }
                        Spacer()
                        Button(app.isInstalled ? "Open" : "Get") {
                            audioEngine.playClickHaptic()
                            viewModel.installStoreApp(id: app.id)
                        }
                        .font(.system(size: 9, weight: .bold))
                        .padding(.horizontal, 12).padding(.vertical, 6)
                        .background(app.isInstalled ? Color.gray.opacity(0.3) : app.accent)
                        .foregroundColor(.white)
                        .clipShape(Capsule())
                    }
                    .padding(10)
                    .background(getBackgroundView(for: viewModel.osMode))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(app.accent.opacity(0.3), lineWidth: 1))
                    .padding(.horizontal, 16)
                }
            }
            .padding(.top, 10)
        }
    }
}

struct PrismAppView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    
    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                Text("PRISM OS KERNEL SWITCHER").font(.system(size: 10, weight: .bold, design: .monospaced)).foregroundColor(.indigo)
                Text(viewModel.isJailbroken ? "Select target operating system mode:" : "⚠️ Switch mode requirements apply.").font(.system(size: 9)).foregroundColor(.gray)
                
                let isExpanderEnabled = viewModel.publishedTweaks.first(where: { $0.title == "Prism OS Expander" })?.isEnabled ?? false
                
                ForEach(OperatingSystemMode.allCases) { mode in
                    let isAllowed: Bool = {
                        if mode == .ios18 {
                            return viewModel.isJailbroken
                        } else if mode == .nyx || mode == .linux || mode == .windows || mode == .off {
                            return true
                        } else {
                            return viewModel.isJailbroken && isExpanderEnabled
                        }
                    }()
                    
                    if isAllowed {
                        Button(action: {
                            audioEngine.playClickHaptic()
                            viewModel.switchOS(to: mode)
                        }) {
                            HStack {
                                Circle().fill(getBackgroundShapeStyle(for: mode == .ios18 ? .ios18 : .android)).frame(width: 8, height: 8)
                                Text(mode.rawValue).font(.system(size: 10, weight: .bold)).foregroundColor(.white)
                                Spacer()
                                if viewModel.osMode == mode {
                                    Image(systemName: "checkmark.circle.fill").foregroundColor(.indigo)
                                }
                            }
                            .padding(10)
                            .background(getBackgroundView(for: viewModel.osMode))
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                            .overlay(RoundedRectangle(cornerRadius: 10).stroke(mode.accent.opacity(0.3), lineWidth: 1))
                        }
                    }
                }
                .padding(.horizontal, 16)
            }
            .padding(.top, 10)
        }
    }
}

struct HorizonWebBrowserView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var networkMonitor: RealNetworkMonitor
    
    @State private var urlString: String = "nyx://home"
    @State private var currentURL: URL = URL(string: "https://www.wikipedia.org")!
    @State private var isCustomHome: Bool = true
    
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 6) {
                Image(systemName: "globe").foregroundColor(Color.cyan).font(.system(size: 10))
                TextField("Enter website URL...", text: $urlString)
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundColor(viewModel.isLightMode ? .black : .white)
                    .autocapitalization(.none)
                    .disableAutocorrection(true)
                    .onSubmit { loadWebURL() }
                
                Button("Go") { loadWebURL() }
                    .font(.system(size: 9, weight: .bold))
                    .foregroundColor(Color.cyan)
            }
            .padding(8)
            .background(getBackgroundView(for: viewModel.osMode))
            
            if isCustomHome {
                VStack(spacing: 14) {
                    Spacer()
                    Image(systemName: "sparkles").font(.system(size: 40)).foregroundColor(.cyan)
                    Text("NYX HORIZON BROWSER").font(.system(size: 12, weight: .bold, design: .monospaced)).foregroundColor(viewModel.isLightMode ? .black : .white)
                    Text("Enter any web URL above or download packages.").font(.system(size: 9)).foregroundColor(.gray)
                    
                    HStack(spacing: 10) {
                        Button("Download Game.ipa") {
                            urlString = "https://nyxos.store/game.ipa"
                            viewModel.addDownloadedFileFromHorizon(filename: "GameClient.ipa")
                        }
                        .font(.system(size: 8, weight: .bold))
                        .padding(.horizontal, 10).padding(.vertical, 6)
                        .background(Color.cyan.opacity(0.2))
                        .foregroundColor(.cyan)
                        .clipShape(Capsule())
                        
                        Button("Download Setup.exe") {
                            urlString = "https://nyxos.store/setup.exe"
                            viewModel.addDownloadedFileFromHorizon(filename: "AppSetup.exe")
                        }
                        .font(.system(size: 8, weight: .bold))
                        .padding(.horizontal, 10).padding(.vertical, 6)
                        .background(Color.blue.opacity(0.2))
                        .foregroundColor(.blue)
                        .clipShape(Capsule())
                    }
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                RealWebViewRepresentable(url: $currentURL)
            }
        }
    }
    
    private func loadWebURL() {
        var formatted = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        if formatted == "nyx://home" || formatted.isEmpty {
            isCustomHome = true
            return
        }
        if !formatted.hasPrefix("http://") && !formatted.hasPrefix("https://") && !formatted.hasPrefix("file://") {
            formatted = "https://" + formatted
        }
        if let u = URL(string: formatted) {
            isCustomHome = false
            currentURL = u
            urlString = u.absoluteString
            
            if formatted.hasSuffix(".ipa") || formatted.hasSuffix(".apk") || formatted.hasSuffix(".exe") || formatted.hasSuffix(".zip") {
                let lastComponent = u.lastPathComponent
                viewModel.addDownloadedFileFromHorizon(filename: lastComponent.isEmpty ? "DownloadFile.zip" : lastComponent)
            }
        }
    }
}

struct RealWebViewRepresentable: UIViewRepresentable {
    @Binding var url: URL
    func makeUIView(context: Context) -> WKWebView {
        let wv = WKWebView()
        wv.load(URLRequest(url: url))
        return wv
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {
        if uiView.url != url {
            uiView.load(URLRequest(url: url))
        }
    }
}

struct AetherToolsetView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @State private var logs: [String] = ["Aether Toolset Diagnostics Active."]
    @State private var input: String = ""
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ScrollView {
                VStack(alignment: .leading) {
                    ForEach(logs, id: \.self) { l in Text(l).font(.system(size: 10, design: .monospaced)).foregroundColor(Color.green) }
                }
            }
            HStack {
                Text("Aether>").foregroundColor(Color.green)
                TextField("command...", text: $input)
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundColor(viewModel.isLightMode ? .black : .white)
                    .autocapitalization(.none)
                    .onSubmit {
                        let cmd = input.trimmingCharacters(in: .whitespacesAndNewlines)
                        let upperCmd = cmd.uppercased()
                        logs.append("Aether> \(input)")
                        
                        if upperCmd == "NYXSUS" {
                            logs.append("[EXPLOIT] Injecting root exploit payload...")
                            logs.append("[REBOOT] Restarting device to apply changes...")
                            viewModel.triggerJailbreakReboot()
                        } else if upperCmd == "DISABLE NYXSUS" {
                            logs.append("[UNROOT] Removing root exploit payload...")
                            logs.append("[REBOOT] Restarting to stock unjailbroken state...")
                            viewModel.triggerRemoveJailbreakReboot()
                        } else if upperCmd == "ACCESS DOWNLOADS" {
                            viewModel.showDownloadsAppUnlocked = true
                            logs.append("[SUCCESS] Downloads app unlocked.")
                        } else if upperCmd == "SIDESTORE…" || cmd == "sidestore…" || upperCmd == "SIDESTORE..." || upperCmd == "SIDESTORE" {
                            viewModel.showNyxSignUnlocked = true
                            logs.append("[SUCCESS] NyxSign (SideStore) unlocked and added to Home Screen!")
                        } else {
                            logs.append("Error: Command not recognized.")
                        }
                        input = ""
                    }
            }
            .padding(6)
            .background(getBackgroundView(for: viewModel.osMode))
        }
        .padding(10)
    }
}

struct SaveCodesAppView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    @State private var generatedCode: String = ""
    
    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                Text("SAVE CODES BACKUP & RESTORE")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundColor(Color.mint)
                
                Button("Generate Save Code") {
                    audioEngine.playClickHaptic()
                    generatedCode = viewModel.generateSaveCode()
                }
                .font(.system(size: 9, weight: .bold))
                .padding(.horizontal, 12).padding(.vertical, 6)
                .background(Color.mint)
                .foregroundColor(.black)
                .clipShape(Capsule())
                
                if !generatedCode.isEmpty {
                    Text(generatedCode).font(.system(size: 8, design: .monospaced)).foregroundColor(.cyan)
                }
                
                Spacer()
            }
            .padding(.top, 10)
        }
    }
}

struct CustomAIAppContainerView: View {
    let customApp: CustomAIApp
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text(customApp.name.uppercased()).font(.system(size: 10, weight: .bold, design: .monospaced)).foregroundColor(Color.cyan)
                Spacer()
                Button(action: { audioEngine.playClickHaptic(); viewModel.activeCustomAiApp = nil }) {
                    Image(systemName: "xmark.circle.fill").foregroundColor(.gray)
                }
            }
            .padding()
            .background(getBackgroundView(for: viewModel.osMode))
            
            Text(customApp.promptText).font(.system(size: 10)).foregroundColor(.white).padding()
            Spacer()
        }
        .background(Color.black)
        .clipShape(RoundedRectangle(cornerRadius: 24))
        .padding(.top, 38)
    }
}

struct RunningSideloadGameContainer: View {
    let game: SideloaderGame
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    
    var body: some View {
        VStack {
            Text(game.title).font(.system(size: 10, weight: .bold)).foregroundColor(Color.red)
            Spacer()
        }
    }
}

struct NativePhotosAppView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    @State private var selectedPhoto: PhotoMediaItem? = nil
    @State private var showImagePicker: Bool = false
    @State private var isPlayingRecording: Bool = false
    @State private var playbackTimer: Timer? = nil
    @State private var playbackSeconds: Int = 0
    
    var body: some View {
        ZStack {
            VStack(spacing: 8) {
                HStack {
                    Text("MEDIA GALLERY").font(.system(size: 10, weight: .bold)).foregroundColor(.pink)
                    Spacer()
                    Button(action: {
                        audioEngine.playClickHaptic()
                        showImagePicker = true
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: "plus")
                            Text("Import")
                        }
                        .font(.system(size: 8, weight: .bold))
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(Color.pink)
                        .foregroundColor(.white)
                        .clipShape(Capsule())
                    }
                }
                .padding(.horizontal, 14)
                .padding(.top, 6)
                
                ScrollView {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: viewModel.isLandscape ? 3 : 2), spacing: 10) {
                        ForEach(viewModel.photoGalleryItems) { item in
                            VStack(spacing: 4) {
                                ZStack(alignment: .topTrailing) {
                                    RoundedRectangle(cornerRadius: 12)
                                        .fill(getBackgroundShapeStyle(for: viewModel.osMode == .ios18 ? .ios18 : .android))
                                        .frame(height: 90)
                                        .overlay(
                                            VStack {
                                                if let img = item.image {
                                                    Image(uiImage: img)
                                                        .resizable()
                                                        .scaledToFill()
                                                        .frame(height: 90)
                                                        .clipShape(RoundedRectangle(cornerRadius: 12))
                                                } else {
                                                    Image(systemName: item.type == "Screenshot" ? "camera.viewfinder" : (item.type == "Recording" ? "video.fill" : "photo.fill"))
                                                        .font(.system(size: 26)).foregroundColor(.pink)
                                                    Text(item.name).font(.system(size: 8, weight: .semibold)).foregroundColor(.white).lineLimit(1)
                                                }
                                            }
                                        )
                                        .overlay(
                                            ZStack {
                                                if item.type == "Recording" {
                                                    RoundedRectangle(cornerRadius: 12).fill(Color.black.opacity(0.3))
                                                    VStack {
                                                        Spacer()
                                                        HStack {
                                                            Image(systemName: "play.circle.fill")
                                                                .font(.system(size: 18))
                                                                .foregroundColor(.white)
                                                            Spacer()
                                                            Text("Video")
                                                                .font(.system(size: 7, weight: .bold, design: .monospaced))
                                                                .foregroundColor(.white)
                                                                .padding(.horizontal, 4)
                                                                .background(Color.black.opacity(0.6))
                                                                .clipShape(Capsule())
                                                        }
                                                        .padding(6)
                                                    }
                                                }
                                            }
                                        )
                                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.pink.opacity(0.3), lineWidth: 1))
                                    
                                    Button(action: {
                                        audioEngine.playClickHaptic()
                                        viewModel.deletePhoto(id: item.id)
                                    }) {
                                        Image(systemName: "trash.circle.fill")
                                            .font(.system(size: 14))
                                            .foregroundColor(.red)
                                            .padding(4)
                                    }
                                }
                                .onTapGesture {
                                    audioEngine.playClickHaptic()
                                    selectedPhoto = item
                                    isPlayingRecording = false
                                    playbackSeconds = 0
                                }
                            }
                        }
                    }.padding(.horizontal, 14)
                }
            }
            
            if let photo = selectedPhoto {
                Color.black.opacity(0.95).ignoresSafeArea()
                    .overlay(
                        VStack(spacing: 16) {
                            HStack {
                                Text(photo.name).font(.system(size: 12, weight: .bold)).foregroundColor(.white)
                                Spacer()
                                Button("Close") {
                                    playbackTimer?.invalidate()
                                    selectedPhoto = nil
                                    isPlayingRecording = false
                                    playbackSeconds = 0
                                }
                                .font(.system(size: 9, weight: .bold)).foregroundColor(.cyan)
                            }
                            .padding(.horizontal, 20)
                            
                            Spacer()
                            
                            ZStack {
                                if let img = photo.image {
                                    TimelineView(.animation) { context in
                                        let timeSeconds = isPlayingRecording ? context.date.timeIntervalSinceReferenceDate : 0
                                        let scaleFactor = isPlayingRecording ? (1.0 + 0.03 * sin(timeSeconds * 2.5)) : 1.0
                                        let rotationAngle = isPlayingRecording ? (0.6 * sin(timeSeconds * 1.5)) : 0.0
                                        
                                        Image(uiImage: img)
                                            .resizable()
                                            .scaledToFit()
                                            .frame(maxHeight: viewModel.isLandscape ? 160 : 250)
                                            .scaleEffect(scaleFactor)
                                            .rotationEffect(.degrees(rotationAngle))
                                            .clipShape(RoundedRectangle(cornerRadius: 12))
                                    }
                                } else {
                                    Image(systemName: photo.type == "Recording" ? "video.fill" : "photo.fill")
                                        .font(.system(size: 70))
                                        .foregroundColor(.pink)
                                }
                                
                                if photo.type == "Recording" && !isPlayingRecording {
                                    Button(action: {
                                        audioEngine.playClickHaptic()
                                        isPlayingRecording = true
                                        playbackSeconds = 0
                                        playbackTimer?.invalidate()
                                        playbackTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
                                            playbackSeconds += 1
                                        }
                                    }) {
                                        Circle()
                                            .fill(Color.black.opacity(0.6))
                                            .frame(width: 60, height: 60)
                                            .overlay(Image(systemName: "play.fill").font(.system(size: 24)).foregroundColor(.white))
                                            .shadow(radius: 10)
                                    }
                                } else if photo.type == "Recording" && isPlayingRecording {
                                    VStack {
                                        Spacer()
                                        VStack(spacing: 6) {
                                            HStack {
                                                Image(systemName: "play.fill").font(.system(size: 8)).foregroundColor(.red)
                                                Text("Playing Recording...")
                                                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                                                    .foregroundColor(.white)
                                                Spacer()
                                                Text(formatTime(playbackSeconds))
                                                    .font(.system(size: 8, design: .monospaced))
                                                    .foregroundColor(.gray)
                                            }
                                            .padding(.horizontal, 20)
                                        }
                                        .padding(.vertical, 8)
                                        .background(Color.black.opacity(0.85))
                                        .clipShape(RoundedRectangle(cornerRadius: 12))
                                    }
                                    .padding(.bottom, 10)
                                }
                            }
                            
                            Text("Type: \(photo.type) • Created: \(photo.date.formatted(date: .omitted, time: .standard))")
                                .font(.system(size: 9))
                                .foregroundColor(.gray)
                            
                            Spacer()
                        }
                        .padding(.vertical, 30)
                    )
            }
        }
        .sheet(isPresented: $showImagePicker) {
            NativeImagePickerRepresentable { name, img in
                viewModel.addImportedPhoto(name: name, image: img)
            }
        }
    }
    
    private func formatTime(_ totalSeconds: Int) -> String {
        let minutes = totalSeconds / 60
        let seconds = totalSeconds % 60
        return String(format: "%d:%02d", minutes, seconds)
    }
}

struct NativeImagePickerRepresentable: UIViewControllerRepresentable {
    var onImagePicked: (String, UIImage) -> Void
    @Environment(\.presentationMode) var presentationMode
    
    func makeUIViewController(context: Context) -> PHPickerViewController {
        var config = PHPickerConfiguration()
        config.filter = .images
        config.selectionLimit = 1
        let picker = PHPickerViewController(configuration: config)
        picker.delegate = context.coordinator
        return picker
    }
    
    func updateUIViewController(_ uiView: PHPickerViewController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let parent: NativeImagePickerRepresentable
        
        init(_ parent: NativeImagePickerRepresentable) {
            self.parent = parent
        }
        
        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)
            
            guard let provider = results.first?.itemProvider, provider.canLoadObject(ofClass: UIImage.self) else {
                return
            }
            
            provider.loadObject(ofClass: UIImage.self) { image, error in
                if let uiImage = image as? UIImage {
                    DispatchQueue.main.async {
                        self.parent.onImagePicked("Photo \(Int.random(in: 100...999))", uiImage)
                    }
                }
            }
        }
    }
}

struct AdvancedControlCenterOverlay: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    @ObservedObject var networkMonitor: RealNetworkMonitor
    
    var body: some View {
        VStack(spacing: 14) {
            HStack {
                Text("NYX CONTROL CENTER").font(.system(size: 10, weight: .bold, design: .monospaced)).foregroundColor(viewModel.systemAccentColor)
                Spacer()
                Button(action: { viewModel.isControlCenterOpen = false }) { Image(systemName: "xmark").foregroundColor(.gray) }
            }
            
            HStack(spacing: 12) {
                Button(action: { audioEngine.playClickHaptic(); viewModel.wifiEnabled.toggle() }) {
                    VStack(spacing: 4) {
                        Image(systemName: viewModel.wifiEnabled ? "wifi" : "wifi.slash").font(.system(size: 16))
                        Text("Wi-Fi").font(.system(size: 7, weight: .bold))
                    }
                    .frame(maxWidth: .infinity, minHeight: 40)
                    .background(viewModel.wifiEnabled ? viewModel.systemAccentColor.opacity(0.3) : Color.white.opacity(0.08))
                    .foregroundColor(viewModel.wifiEnabled ? viewModel.systemAccentColor : Color.gray)
                    .clipShape(RoundedRectangle(cornerRadius: viewModel.osMode == .android ? 14 : 10))
                    .overlay(RoundedRectangle(cornerRadius: viewModel.osMode == .android ? 14 : 10).stroke(viewModel.systemAccentColor.opacity(0.3), lineWidth: 1))
                }
                
                Button(action: { audioEngine.playClickHaptic(); viewModel.bluetoothEnabled.toggle() }) {
                    VStack(spacing: 4) {
                        Image(systemName: viewModel.bluetoothEnabled ? "bluetooth" : "wifi.slash").font(.system(size: 16))
                        Text("Bluetooth").font(.system(size: 7, weight: .bold))
                    }
                    .frame(maxWidth: .infinity, minHeight: 40)
                    .background(viewModel.bluetoothEnabled ? Color.blue.opacity(0.3) : Color.white.opacity(0.08))
                    .foregroundColor(viewModel.bluetoothEnabled ? Color.blue : Color.gray)
                    .clipShape(RoundedRectangle(cornerRadius: viewModel.osMode == .android ? 14 : 10))
                    .overlay(RoundedRectangle(cornerRadius: viewModel.osMode == .android ? 14 : 10).stroke(Color.blue.opacity(0.3), lineWidth: 1))
                }
                
                Button(action: { audioEngine.playClickHaptic(); viewModel.isLightMode.toggle() }) {
                    VStack(spacing: 4) {
                        Image(systemName: viewModel.isLightMode ? "sun.max.fill" : "moon.fill").font(.system(size: 16))
                        Text("Theme").font(.system(size: 7, weight: .bold))
                    }
                    .frame(maxWidth: .infinity, minHeight: 40)
                    .background(Color.white.opacity(0.08))
                    .foregroundColor(.yellow)
                    .clipShape(RoundedRectangle(cornerRadius: viewModel.osMode == .android ? 14 : 10))
                    .overlay(RoundedRectangle(cornerRadius: viewModel.osMode == .android ? 14 : 10).stroke(Color.yellow.opacity(0.3), lineWidth: 1))
                }
                
                Button(action: {
                    audioEngine.playClickHaptic()
                    withAnimation {
                        viewModel.isLandscape.toggle()
                    }
                }) {
                    VStack(spacing: 4) {
                        Image(systemName: viewModel.isLandscape ? "rectangle.landscape.rotate" : "rectangle.portrait.rotate").font(.system(size: 16))
                        Text(viewModel.isLandscape ? "Landscape" : "Portrait").font(.system(size: 7, weight: .bold))
                    }
                    .frame(maxWidth: .infinity, minHeight: 40)
                    .background(viewModel.isLandscape ? Color.purple.opacity(0.4) : Color.white.opacity(0.08))
                    .foregroundColor(viewModel.isLandscape ? Color.purple : Color.gray)
                    .clipShape(RoundedRectangle(cornerRadius: viewModel.osMode == .android ? 14 : 10))
                    .overlay(RoundedRectangle(cornerRadius: viewModel.osMode == .android ? 14 : 10).stroke(Color.purple.opacity(0.3), lineWidth: 1))
                }
            }
            
            let isMultitaskTweakEnabled = viewModel.publishedTweaks.first(where: { $0.title == "NyxSplit Multitasker" })?.isEnabled ?? false
            if viewModel.isJailbroken && isMultitaskTweakEnabled {
                Button(action: {
                    audioEngine.playClickHaptic()
                    viewModel.isDesktopModeActive.toggle()
                    viewModel.isControlCenterOpen = false
                }) {
                    HStack {
                        Image(systemName: "square.split.2x2.fill").foregroundColor(viewModel.systemAccentColor)
                        Text(viewModel.isDesktopModeActive ? "Exit Desktop Mode" : "Enable PC Desktop Workspace").font(.system(size: 9, weight: .bold)).foregroundColor(.white)
                    }
                    .padding(8).frame(maxWidth: .infinity).background(getBackgroundView(for: viewModel.osMode)).clipShape(RoundedRectangle(cornerRadius: 10))
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(viewModel.systemAccentColor.opacity(0.3), lineWidth: 1))
                }
            }
            
            Button(action: { audioEngine.playClickHaptic(); viewModel.toggleScreenRecording() }) {
                HStack {
                    Circle().fill(viewModel.isRecordingScreen ? Color.red : Color.gray).frame(width: 10, height: 10)
                    Text(viewModel.isRecordingScreen ? "Stop Recording (Saving to Photos...)" : "Start Screen Recording").font(.system(size: 9, weight: .bold)).foregroundColor(.white)
                }
                .padding(8).frame(maxWidth: .infinity).background(viewModel.isRecordingScreen ? Color.red.opacity(0.3) : Color.white.opacity(0.1)).clipShape(RoundedRectangle(cornerRadius: 10))
            }
        }
        .padding()
        .frame(height: 230)
        .background(getBackgroundView(for: viewModel.osMode))
        .clipShape(RoundedRectangle(cornerRadius: 24))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(viewModel.systemAccentColor.opacity(0.4), lineWidth: 1))
        .padding(.horizontal, 16)
        .padding(.top, 45)
    }
}

struct SettingsAppView: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var networkMonitor: RealNetworkMonitor
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Text("SYSTEM SETTINGS & PREFERENCES").font(.system(size: 10, weight: .bold)).foregroundColor(viewModel.systemAccentColor)
                
                VStack(alignment: .leading, spacing: 6) {
                    Text("Identity: \(viewModel.loggedInUserProvider)").font(.system(size: 9, weight: .bold)).foregroundColor(.white)
                    Text("Kernel Status: \(viewModel.isJailbroken ? "Jailbroken (Rooted)" : "Stock (Unjailbroken)")").font(.system(size: 9, weight: .bold)).foregroundColor(viewModel.isJailbroken ? .orange : .gray)
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(getBackgroundView(for: viewModel.osMode))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(viewModel.systemAccentColor.opacity(0.3), lineWidth: 1))
                
                Text("Display & Brightness").font(.system(size: 9, weight: .bold)).foregroundColor(.gray)
                VStack(spacing: 8) {
                    HStack {
                        Text("Brightness").font(.system(size: 9)).foregroundColor(.white)
                        Spacer()
                        Text("\(Int(viewModel.screenBrightness * 100))%").font(.system(size: 9)).foregroundColor(.gray)
                    }
                    Slider(value: $viewModel.screenBrightness, in: 0.2...1.0)
                        .accentColor(viewModel.systemAccentColor)
                }
                .padding(10)
                .background(getBackgroundView(for: viewModel.osMode))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white.opacity(0.1), lineWidth: 1))
                
                Text("Audio & Volume Levels").font(.system(size: 9, weight: .bold)).foregroundColor(.gray)
                VStack(spacing: 8) {
                    HStack {
                        Text("System Volume").font(.system(size: 9)).foregroundColor(.white)
                        Spacer()
                        Text("\(Int(viewModel.volumeLevel * 100))%").font(.system(size: 9)).foregroundColor(.gray)
                    }
                    Slider(value: $viewModel.volumeLevel, in: 0.0...1.0)
                        .accentColor(viewModel.systemAccentColor)
                }
                .padding(10)
                .background(getBackgroundView(for: viewModel.osMode))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white.opacity(0.1), lineWidth: 1))
                
                Text("Connectivity & Bluetooth").font(.system(size: 9, weight: .bold)).foregroundColor(.gray)
                VStack(alignment: .leading, spacing: 6) {
                    Toggle("Wi-Fi Interface", isOn: $viewModel.wifiEnabled)
                        .font(.system(size: 9))
                    Toggle("Bluetooth Hardware", isOn: $viewModel.bluetoothEnabled)
                        .font(.system(size: 9))
                    Text("Connected Audio: \(viewModel.connectedBluetoothDevice)").font(.system(size: 8)).foregroundColor(viewModel.systemAccentColor)
                }
                .padding(10)
                .background(getBackgroundView(for: viewModel.osMode))
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white.opacity(0.1), lineWidth: 1))
                
                Text("System Language (All World Languages)").font(.system(size: 9, weight: .bold)).foregroundColor(.gray)
                Picker("Language", selection: $viewModel.currentLanguage) {
                    ForEach(AppLanguage.allCases) { lang in
                        Text(lang.rawValue).tag(lang)
                    }
                }
                .pickerStyle(MenuPickerStyle())
            }
            .padding()
        }
    }
}

struct WindowsExeInstallerPopup: View {
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    var body: some View {
        VStack(spacing: 10) {
            Text("SETUP WIZARD").font(.system(size: 10, weight: .bold)).foregroundColor(.blue)
            Text(viewModel.pendingExeFileName).font(.system(size: 9)).foregroundColor(.gray)
            Button("Install") { viewModel.confirmWindowsInstallation() }
            .font(.system(size: 9, weight: .bold)).padding(6).background(Color.blue).foregroundColor(.white).clipShape(Capsule())
        }
        .padding(16).background(getBackgroundView(for: viewModel.osMode)).clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

struct RunningExeAppContainerView: View {
    let exeApp: StoreApp
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    var body: some View {
        VStack {
            Text("Win32: \(exeApp.name)").font(.system(size: 10, weight: .bold)).foregroundColor(.blue)
            Spacer()
        }
    }
}

struct RunningGameContainerView: View {
    let game: StoreApp
    @ObservedObject var viewModel: NyxOSViewModel
    @ObservedObject var audioEngine: NyxAudioEngine
    var body: some View {
        VStack {
            Text("Game Engine: \(game.name)").font(.system(size: 10, weight: .bold)).foregroundColor(game.accent)
            Spacer()
        }
    }
}

